int fatalError;
int lineno;
char *filename = "tests";
char buffer[4096];
char scratchFileName[4096];
