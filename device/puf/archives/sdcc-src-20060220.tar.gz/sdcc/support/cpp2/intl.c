/* intl.c - internationalization */

#include "auto-host.h"
#include "ansidecl.h"
#include "intl.h"

const char localedir[] = LOCALEDIR;
