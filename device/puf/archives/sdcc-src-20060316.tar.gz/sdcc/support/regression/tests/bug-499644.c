/* Floats
 */
#include <testfwk.h>

const float a = 0.0; 

float f(void) 
{ 
  return a * 5; 
} 
