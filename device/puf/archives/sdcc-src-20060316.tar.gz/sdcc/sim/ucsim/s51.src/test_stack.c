void jaj(void)
{
	jaj();
}

void main(void)
{
	jaj();
}
