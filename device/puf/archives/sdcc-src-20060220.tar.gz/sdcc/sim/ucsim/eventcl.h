/*@1@*/

#ifndef EVENTCL_HEADER
#define EVENTCL_HEADER


enum event {
  ev_nothing			= 0x00000000,

  ev_address_space_added	= 0x00000001
};


#endif

/* End of eventcl.h */
