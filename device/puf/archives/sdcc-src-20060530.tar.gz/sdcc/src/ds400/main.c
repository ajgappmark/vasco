/* This is currently a stub. The guts of the '400 implementation
 * still live in the ds390 directory.
 */

#include "main.h"

/* If we don't have at least one exported function, the Solaris
 * linker freaks out.
 */

void ds400_dummyFunc(void)
{
    ;
}
