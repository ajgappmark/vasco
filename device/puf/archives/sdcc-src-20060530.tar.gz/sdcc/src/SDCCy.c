/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     IDENTIFIER = 258,
     TYPE_NAME = 259,
     CONSTANT = 260,
     STRING_LITERAL = 261,
     SIZEOF = 262,
     TYPEOF = 263,
     PTR_OP = 264,
     INC_OP = 265,
     DEC_OP = 266,
     LEFT_OP = 267,
     RIGHT_OP = 268,
     LE_OP = 269,
     GE_OP = 270,
     EQ_OP = 271,
     NE_OP = 272,
     AND_OP = 273,
     OR_OP = 274,
     MUL_ASSIGN = 275,
     DIV_ASSIGN = 276,
     MOD_ASSIGN = 277,
     ADD_ASSIGN = 278,
     SUB_ASSIGN = 279,
     LEFT_ASSIGN = 280,
     RIGHT_ASSIGN = 281,
     AND_ASSIGN = 282,
     XOR_ASSIGN = 283,
     OR_ASSIGN = 284,
     TYPEDEF = 285,
     EXTERN = 286,
     STATIC = 287,
     AUTO = 288,
     REGISTER = 289,
     CODE = 290,
     EEPROM = 291,
     INTERRUPT = 292,
     SFR = 293,
     SFR16 = 294,
     SFR32 = 295,
     AT = 296,
     SBIT = 297,
     REENTRANT = 298,
     USING = 299,
     XDATA = 300,
     DATA = 301,
     IDATA = 302,
     PDATA = 303,
     VAR_ARGS = 304,
     CRITICAL = 305,
     NONBANKED = 306,
     BANKED = 307,
     SHADOWREGS = 308,
     WPARAM = 309,
     CHAR = 310,
     SHORT = 311,
     INT = 312,
     LONG = 313,
     SIGNED = 314,
     UNSIGNED = 315,
     FLOAT = 316,
     DOUBLE = 317,
     FIXED16X16 = 318,
     CONST = 319,
     VOLATILE = 320,
     VOID = 321,
     BIT = 322,
     STRUCT = 323,
     UNION = 324,
     ENUM = 325,
     ELIPSIS = 326,
     RANGE = 327,
     FAR = 328,
     CASE = 329,
     DEFAULT = 330,
     IF = 331,
     ELSE = 332,
     SWITCH = 333,
     WHILE = 334,
     DO = 335,
     FOR = 336,
     GOTO = 337,
     CONTINUE = 338,
     BREAK = 339,
     RETURN = 340,
     NAKED = 341,
     JAVANATIVE = 342,
     OVERLAY = 343,
     INLINEASM = 344,
     IFX = 345,
     ADDRESS_OF = 346,
     GET_VALUE_AT_ADDRESS = 347,
     SPIL = 348,
     UNSPIL = 349,
     GETHBIT = 350,
     GETABIT = 351,
     GETBYTE = 352,
     GETWORD = 353,
     BITWISEAND = 354,
     UNARYMINUS = 355,
     IPUSH = 356,
     IPOP = 357,
     PCALL = 358,
     ENDFUNCTION = 359,
     JUMPTABLE = 360,
     RRC = 361,
     RLC = 362,
     CAST = 363,
     CALL = 364,
     PARAM = 365,
     NULLOP = 366,
     BLOCK = 367,
     LABEL = 368,
     RECEIVE = 369,
     SEND = 370,
     ARRAYINIT = 371,
     DUMMY_READ_VOLATILE = 372,
     ENDCRITICAL = 373,
     SWAP = 374,
     INLINE = 375,
     RESTRICT = 376
   };
#endif
/* Tokens.  */
#define IDENTIFIER 258
#define TYPE_NAME 259
#define CONSTANT 260
#define STRING_LITERAL 261
#define SIZEOF 262
#define TYPEOF 263
#define PTR_OP 264
#define INC_OP 265
#define DEC_OP 266
#define LEFT_OP 267
#define RIGHT_OP 268
#define LE_OP 269
#define GE_OP 270
#define EQ_OP 271
#define NE_OP 272
#define AND_OP 273
#define OR_OP 274
#define MUL_ASSIGN 275
#define DIV_ASSIGN 276
#define MOD_ASSIGN 277
#define ADD_ASSIGN 278
#define SUB_ASSIGN 279
#define LEFT_ASSIGN 280
#define RIGHT_ASSIGN 281
#define AND_ASSIGN 282
#define XOR_ASSIGN 283
#define OR_ASSIGN 284
#define TYPEDEF 285
#define EXTERN 286
#define STATIC 287
#define AUTO 288
#define REGISTER 289
#define CODE 290
#define EEPROM 291
#define INTERRUPT 292
#define SFR 293
#define SFR16 294
#define SFR32 295
#define AT 296
#define SBIT 297
#define REENTRANT 298
#define USING 299
#define XDATA 300
#define DATA 301
#define IDATA 302
#define PDATA 303
#define VAR_ARGS 304
#define CRITICAL 305
#define NONBANKED 306
#define BANKED 307
#define SHADOWREGS 308
#define WPARAM 309
#define CHAR 310
#define SHORT 311
#define INT 312
#define LONG 313
#define SIGNED 314
#define UNSIGNED 315
#define FLOAT 316
#define DOUBLE 317
#define FIXED16X16 318
#define CONST 319
#define VOLATILE 320
#define VOID 321
#define BIT 322
#define STRUCT 323
#define UNION 324
#define ENUM 325
#define ELIPSIS 326
#define RANGE 327
#define FAR 328
#define CASE 329
#define DEFAULT 330
#define IF 331
#define ELSE 332
#define SWITCH 333
#define WHILE 334
#define DO 335
#define FOR 336
#define GOTO 337
#define CONTINUE 338
#define BREAK 339
#define RETURN 340
#define NAKED 341
#define JAVANATIVE 342
#define OVERLAY 343
#define INLINEASM 344
#define IFX 345
#define ADDRESS_OF 346
#define GET_VALUE_AT_ADDRESS 347
#define SPIL 348
#define UNSPIL 349
#define GETHBIT 350
#define GETABIT 351
#define GETBYTE 352
#define GETWORD 353
#define BITWISEAND 354
#define UNARYMINUS 355
#define IPUSH 356
#define IPOP 357
#define PCALL 358
#define ENDFUNCTION 359
#define JUMPTABLE 360
#define RRC 361
#define RLC 362
#define CAST 363
#define CALL 364
#define PARAM 365
#define NULLOP 366
#define BLOCK 367
#define LABEL 368
#define RECEIVE 369
#define SEND 370
#define ARRAYINIT 371
#define DUMMY_READ_VOLATILE 372
#define ENDCRITICAL 373
#define SWAP 374
#define INLINE 375
#define RESTRICT 376




/* Copy the first part of user declarations.  */
#line 24 "SDCC.y"

#include <stdio.h>
#include <stdarg.h> 
#include <string.h>
#include "SDCCglobl.h"
#include "SDCCsymt.h"
#include "SDCChasht.h"
#include "SDCCval.h"
#include "SDCCmem.h"
#include "SDCCast.h"
#include "port.h"
#include "newalloc.h"
#include "SDCCerr.h"
#include "SDCCutil.h"

extern int yyerror (char *);
extern FILE	*yyin;
int NestLevel = 0 ;     /* current NestLevel       */
int stackPtr  = 1 ;     /* stack pointer           */
int xstackPtr = 0 ;     /* xstack pointer          */
int reentrant = 0 ; 
int blockNo   = 0 ;     /* sequential block number  */
int currBlockno=0 ;
int inCritical= 0 ;
int seqPointNo= 1 ;	/* sequence point number */
int ignoreTypedefType=0;
extern int yylex();
int yyparse(void);
extern int noLineno ;
char lbuff[1024];      /* local buffer */

/* break & continue stacks */
STACK_DCL(continueStack  ,symbol *,MAX_NEST_LEVEL)
STACK_DCL(breakStack  ,symbol *,MAX_NEST_LEVEL)
STACK_DCL(forStack  ,symbol *,MAX_NEST_LEVEL)
STACK_DCL(swStk   ,ast   *,MAX_NEST_LEVEL)
STACK_DCL(blockNum,int,MAX_NEST_LEVEL*3)

value *cenum = NULL  ;  /* current enumeration  type chain*/
bool uselessDecl = TRUE;

#define YYDEBUG 1



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 70 "SDCC.y"
typedef union YYSTYPE {
    symbol     *sym ;      /* symbol table pointer       */
    structdef  *sdef;      /* structure definition       */
    char       yychar[SDCC_NAME_MAX+1];
    sym_link   *lnk ;      /* declarator  or specifier   */
    int        yyint;      /* integer value returned     */
    value      *val ;      /* for integer constant       */
    initList   *ilist;     /* initial list               */
    const char *yyinline;  /* inlined assembler code     */
    ast        *asts;      /* expression tree            */
} YYSTYPE;
/* Line 196 of yacc.c.  */
#line 384 "SDCCy.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 219 of yacc.c.  */
#line 396 "SDCCy.c"

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T) && (defined (__STDC__) || defined (__cplusplus))
# include <stddef.h> /* INFRINGES ON USER NAME SPACE */
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if defined (__STDC__) || defined (__cplusplus)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     define YYINCLUDED_STDLIB_H
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2005 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM ((YYSIZE_T) -1)
#  endif
#  ifdef __cplusplus
extern "C" {
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if (! defined (malloc) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if (! defined (free) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifdef __cplusplus
}
#  endif
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short int yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short int) + sizeof (YYSTYPE))			\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short int yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  63
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1689

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  146
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  104
/* YYNRULES -- Number of rules. */
#define YYNRULES  280
/* YYNRULES -- Number of states. */
#define YYNSTATES  419

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   376

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   133,     2,     2,     2,   135,   128,     2,
     122,   123,   129,   130,   127,   131,   126,   134,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   141,   143,
     136,   142,   137,   140,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   124,     2,   125,   138,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   144,   139,   145,   132,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     5,     8,    10,    12,    15,    19,    21,
      24,    27,    29,    31,    33,    35,    37,    39,    41,    43,
      45,    47,    49,    52,    54,    56,    58,    62,    64,    66,
      71,    75,    80,    81,    86,    87,    92,    95,    98,   100,
     104,   106,   109,   112,   115,   118,   123,   126,   128,   130,
     132,   134,   136,   138,   140,   145,   147,   151,   155,   159,
     161,   165,   169,   171,   175,   179,   181,   185,   189,   193,
     197,   199,   203,   207,   209,   213,   215,   219,   221,   225,
     227,   228,   233,   235,   236,   241,   243,   244,   251,   253,
     257,   259,   261,   263,   265,   267,   269,   271,   273,   275,
     277,   279,   281,   282,   287,   289,   292,   296,   298,   301,
     303,   306,   308,   312,   314,   318,   320,   322,   324,   326,
     328,   330,   333,   335,   339,   341,   343,   345,   347,   349,
     351,   353,   355,   357,   359,   361,   363,   365,   367,   369,
     371,   373,   375,   377,   379,   381,   383,   385,   387,   389,
     392,   394,   396,   397,   404,   407,   409,   411,   413,   414,
     416,   418,   421,   425,   427,   431,   433,   436,   440,   441,
     446,   452,   455,   457,   460,   464,   467,   470,   471,   473,
     476,   478,   480,   482,   485,   487,   490,   492,   496,   500,
     505,   509,   510,   516,   521,   523,   526,   529,   533,   535,
     537,   540,   542,   546,   548,   552,   554,   558,   560,   564,
     567,   569,   571,   574,   576,   578,   581,   585,   588,   592,
     596,   601,   604,   608,   612,   613,   619,   621,   625,   630,
     632,   636,   638,   640,   642,   644,   646,   648,   650,   653,
     655,   658,   661,   665,   666,   670,   672,   674,   677,   681,
     682,   687,   688,   694,   697,   699,   702,   704,   707,   709,
     712,   715,   716,   717,   725,   726,   733,   735,   737,   739,
     740,   747,   755,   765,   766,   768,   772,   775,   778,   781,
     785
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     147,     0,    -1,   148,    -1,   147,   148,    -1,   149,    -1,
     181,    -1,   206,   152,    -1,   182,   206,   152,    -1,   151,
      -1,   151,   150,    -1,    44,   180,    -1,    43,    -1,    50,
      -1,    86,    -1,    87,    -1,    88,    -1,    51,    -1,    53,
      -1,    54,    -1,    52,    -1,   186,    -1,   232,    -1,   235,
     232,    -1,   249,    -1,     5,    -1,   154,    -1,   122,   178,
     123,    -1,     6,    -1,   153,    -1,   155,   124,   178,   125,
      -1,   155,   122,   123,    -1,   155,   122,   158,   123,    -1,
      -1,   155,   126,   156,   249,    -1,    -1,   155,     9,   157,
     249,    -1,   155,    10,    -1,   155,    11,    -1,   176,    -1,
     176,   127,   158,    -1,   155,    -1,    10,   159,    -1,    11,
     159,    -1,   160,   161,    -1,     7,   159,    -1,     7,   122,
     219,   123,    -1,     8,   159,    -1,   128,    -1,   129,    -1,
     130,    -1,   131,    -1,   132,    -1,   133,    -1,   159,    -1,
     122,   219,   123,   161,    -1,   161,    -1,   162,   129,   161,
      -1,   162,   134,   161,    -1,   162,   135,   161,    -1,   162,
      -1,   163,   130,   162,    -1,   163,   131,   162,    -1,   163,
      -1,   164,    12,   163,    -1,   164,    13,   163,    -1,   164,
      -1,   165,   136,   164,    -1,   165,   137,   164,    -1,   165,
      14,   164,    -1,   165,    15,   164,    -1,   165,    -1,   166,
      16,   165,    -1,   166,    17,   165,    -1,   166,    -1,   167,
     128,   166,    -1,   167,    -1,   168,   138,   167,    -1,   168,
      -1,   169,   139,   168,    -1,   169,    -1,    -1,   170,    18,
     171,   169,    -1,   170,    -1,    -1,   172,    19,   173,   170,
      -1,   172,    -1,    -1,   172,   140,   175,   172,   141,   174,
      -1,   174,    -1,   161,   177,   176,    -1,   142,    -1,    20,
      -1,    21,    -1,    22,    -1,    23,    -1,    24,    -1,    25,
      -1,    26,    -1,    27,    -1,    28,    -1,    29,    -1,   176,
      -1,    -1,   178,   127,   179,   176,    -1,   174,    -1,   182,
     143,    -1,   182,   183,   143,    -1,   185,    -1,   185,   182,
      -1,   187,    -1,   187,   182,    -1,   184,    -1,   183,   127,
     184,    -1,   204,    -1,   204,   142,   223,    -1,    30,    -1,
      31,    -1,    32,    -1,    33,    -1,    34,    -1,    37,    -1,
      37,   180,    -1,   188,    -1,   188,    41,   180,    -1,    55,
      -1,    56,    -1,    57,    -1,    58,    -1,    59,    -1,    60,
      -1,    66,    -1,    64,    -1,    65,    -1,    61,    -1,    63,
      -1,    45,    -1,    35,    -1,    36,    -1,    46,    -1,    47,
      -1,    48,    -1,    67,    -1,   191,    -1,   200,    -1,     4,
      -1,   189,    -1,    42,    -1,   190,    -1,    38,    -1,    38,
      52,    -1,    39,    -1,    40,    -1,    -1,   193,   194,   192,
     144,   196,   145,    -1,   193,   195,    -1,    68,    -1,    69,
      -1,   195,    -1,    -1,   249,    -1,   197,    -1,   196,   197,
      -1,   213,   198,   143,    -1,   199,    -1,   198,   127,   199,
      -1,   204,    -1,   141,   180,    -1,   204,   141,   180,    -1,
      -1,    70,   144,   201,   145,    -1,    70,   249,   144,   201,
     145,    -1,    70,   249,    -1,   202,    -1,   201,   127,    -1,
     201,   127,   202,    -1,   249,   203,    -1,   142,   180,    -1,
      -1,   205,    -1,   211,   205,    -1,   207,    -1,   208,    -1,
     207,    -1,   211,   207,    -1,   209,    -1,   209,   150,    -1,
     249,    -1,   122,   204,   123,    -1,   205,   124,   125,    -1,
     205,   124,   180,   125,    -1,   208,   122,   123,    -1,    -1,
     208,   122,   210,   216,   123,    -1,   208,   122,   214,   123,
      -1,   212,    -1,   212,   213,    -1,   212,   211,    -1,   212,
     213,   211,    -1,   129,    -1,   187,    -1,   213,   187,    -1,
     215,    -1,   215,   127,    71,    -1,   249,    -1,   215,   127,
     249,    -1,   217,    -1,   217,   127,    49,    -1,   218,    -1,
     217,   127,   218,    -1,   213,   204,    -1,   219,    -1,   213,
      -1,   213,   220,    -1,   211,    -1,   221,    -1,   211,   221,
      -1,   122,   220,   123,    -1,   124,   125,    -1,   124,   180,
     125,    -1,   221,   124,   125,    -1,   221,   124,   180,   125,
      -1,   122,   123,    -1,   122,   216,   123,    -1,   221,   122,
     123,    -1,    -1,   221,   122,   222,   216,   123,    -1,   176,
      -1,   144,   224,   145,    -1,   144,   224,   127,   145,    -1,
     223,    -1,   224,   127,   223,    -1,   228,    -1,   232,    -1,
     237,    -1,   239,    -1,   245,    -1,   248,    -1,   227,    -1,
      89,   143,    -1,    50,    -1,   226,   225,    -1,   249,   141,
      -1,    74,   180,   141,    -1,    -1,    75,   229,   141,    -1,
     144,    -1,   145,    -1,   230,   231,    -1,   230,   236,   231,
      -1,    -1,   230,   235,   233,   231,    -1,    -1,   230,   235,
     234,   236,   231,    -1,     1,   143,    -1,   181,    -1,   235,
     181,    -1,   225,    -1,   236,   225,    -1,   143,    -1,   178,
     143,    -1,    77,   225,    -1,    -1,    -1,    76,   122,   178,
     123,   240,   225,   238,    -1,    -1,    78,   122,   178,   123,
     241,   225,    -1,    79,    -1,    80,    -1,    81,    -1,    -1,
     242,   122,   178,   123,   246,   225,    -1,   243,   225,    79,
     122,   178,   123,   143,    -1,   244,   122,   247,   143,   247,
     143,   247,   123,   225,    -1,    -1,   178,    -1,    82,   249,
     143,    -1,    83,   143,    -1,    84,   143,    -1,    85,   143,
      -1,    85,   178,   143,    -1,     3,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   136,   136,   137,   141,   144,   170,   175,   184,   185,
     189,   193,   196,   199,   202,   205,   208,   214,   217,   220,
     229,   238,   239,   247,   248,   249,   250,   254,   258,   259,
     260,   262,   266,   266,   274,   274,   281,   283,   288,   289,
     293,   294,   295,   296,   297,   298,   299,   303,   304,   305,
     306,   307,   308,   312,   313,   317,   318,   319,   320,   324,
     325,   326,   330,   331,   332,   336,   337,   342,   347,   352,
     360,   361,   366,   374,   375,   379,   380,   384,   385,   389,
     390,   390,   395,   396,   396,   401,   402,   402,   410,   411,
     467,   468,   469,   470,   471,   472,   473,   474,   475,   476,
     477,   481,   482,   482,   486,   490,   497,   515,   516,   529,
     530,   546,   547,   551,   552,   557,   561,   565,   569,   573,
     580,   581,   594,   595,   605,   610,   615,   620,   625,   630,
     635,   640,   644,   648,   653,   658,   662,   666,   670,   674,
     678,   682,   691,   696,   702,   711,   715,   723,   727,   735,
     746,   757,   770,   769,   818,   837,   838,   842,   843,   850,
     861,   862,   875,   901,   902,   910,   911,   923,   939,   944,
     949,   969,   983,   984,   986,  1005,  1019,  1032,  1047,  1048,
    1056,  1057,  1061,  1062,  1070,  1071,  1103,  1104,  1105,  1114,
    1137,  1138,  1138,  1164,  1174,  1175,  1186,  1192,  1230,  1238,
    1240,  1256,  1257,  1261,  1262,  1270,  1271,  1275,  1276,  1284,
    1294,  1303,  1304,  1321,  1322,  1323,  1330,  1331,  1336,  1342,
    1348,  1356,  1357,  1358,  1370,  1370,  1394,  1395,  1396,  1400,
    1401,  1405,  1406,  1407,  1408,  1409,  1410,  1411,  1412,  1423,
    1432,  1442,  1444,  1451,  1451,  1460,  1468,  1472,  1473,  1475,
    1474,  1478,  1477,  1481,  1485,  1497,  1522,  1523,  1527,  1528,
    1532,  1533,  1538,  1538,  1544,  1544,  1569,  1583,  1598,  1617,
    1617,  1625,  1634,  1662,  1663,  1667,  1672,  1685,  1695,  1704,
    1716
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "IDENTIFIER", "TYPE_NAME", "CONSTANT",
  "STRING_LITERAL", "SIZEOF", "TYPEOF", "PTR_OP", "INC_OP", "DEC_OP",
  "LEFT_OP", "RIGHT_OP", "LE_OP", "GE_OP", "EQ_OP", "NE_OP", "AND_OP",
  "OR_OP", "MUL_ASSIGN", "DIV_ASSIGN", "MOD_ASSIGN", "ADD_ASSIGN",
  "SUB_ASSIGN", "LEFT_ASSIGN", "RIGHT_ASSIGN", "AND_ASSIGN", "XOR_ASSIGN",
  "OR_ASSIGN", "TYPEDEF", "EXTERN", "STATIC", "AUTO", "REGISTER", "CODE",
  "EEPROM", "INTERRUPT", "SFR", "SFR16", "SFR32", "AT", "SBIT",
  "REENTRANT", "USING", "XDATA", "DATA", "IDATA", "PDATA", "VAR_ARGS",
  "CRITICAL", "NONBANKED", "BANKED", "SHADOWREGS", "WPARAM", "CHAR",
  "SHORT", "INT", "LONG", "SIGNED", "UNSIGNED", "FLOAT", "DOUBLE",
  "FIXED16X16", "CONST", "VOLATILE", "VOID", "BIT", "STRUCT", "UNION",
  "ENUM", "ELIPSIS", "RANGE", "FAR", "CASE", "DEFAULT", "IF", "ELSE",
  "SWITCH", "WHILE", "DO", "FOR", "GOTO", "CONTINUE", "BREAK", "RETURN",
  "NAKED", "JAVANATIVE", "OVERLAY", "INLINEASM", "IFX", "ADDRESS_OF",
  "GET_VALUE_AT_ADDRESS", "SPIL", "UNSPIL", "GETHBIT", "GETABIT",
  "GETBYTE", "GETWORD", "BITWISEAND", "UNARYMINUS", "IPUSH", "IPOP",
  "PCALL", "ENDFUNCTION", "JUMPTABLE", "RRC", "RLC", "CAST", "CALL",
  "PARAM", "NULLOP", "BLOCK", "LABEL", "RECEIVE", "SEND", "ARRAYINIT",
  "DUMMY_READ_VOLATILE", "ENDCRITICAL", "SWAP", "INLINE", "RESTRICT",
  "'('", "')'", "'['", "']'", "'.'", "','", "'&'", "'*'", "'+'", "'-'",
  "'~'", "'!'", "'/'", "'%'", "'<'", "'>'", "'^'", "'|'", "'?'", "':'",
  "'='", "';'", "'{'", "'}'", "$accept", "file", "external_definition",
  "function_definition", "function_attribute", "function_attributes",
  "function_body", "primary_expr", "string_literal", "postfix_expr", "@1",
  "@2", "argument_expr_list", "unary_expr", "unary_operator", "cast_expr",
  "multiplicative_expr", "additive_expr", "shift_expr", "relational_expr",
  "equality_expr", "and_expr", "exclusive_or_expr", "inclusive_or_expr",
  "logical_and_expr", "@3", "logical_or_expr", "@4", "conditional_expr",
  "@5", "assignment_expr", "assignment_operator", "expr", "@6",
  "constant_expr", "declaration", "declaration_specifiers",
  "init_declarator_list", "init_declarator", "storage_class_specifier",
  "Interrupt_storage", "type_specifier", "type_specifier2", "sfr_reg_bit",
  "sfr_attributes", "struct_or_union_specifier", "@7", "struct_or_union",
  "opt_stag", "stag", "struct_declaration_list", "struct_declaration",
  "struct_declarator_list", "struct_declarator", "enum_specifier",
  "enumerator_list", "enumerator", "opt_assign_expr", "declarator",
  "declarator3", "function_declarator", "declarator2_function_attributes",
  "declarator2", "function_declarator2", "@8", "pointer",
  "unqualified_pointer", "type_specifier_list",
  "parameter_identifier_list", "identifier_list", "parameter_type_list",
  "parameter_list", "parameter_declaration", "type_name",
  "abstract_declarator", "abstract_declarator2", "@9", "initializer",
  "initializer_list", "statement", "critical", "critical_statement",
  "labeled_statement", "@10", "start_block", "end_block",
  "compound_statement", "@11", "@12", "declaration_list", "statement_list",
  "expression_statement", "else_statement", "selection_statement", "@13",
  "@14", "while", "do", "for", "iteration_statement", "@15", "expr_opt",
  "jump_statement", "identifier", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short int yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,    40,    41,    91,    93,    46,    44,    38,    42,
      43,    45,   126,    33,    47,    37,    60,    62,    94,   124,
      63,    58,    61,    59,   123,   125
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   146,   147,   147,   148,   148,   149,   149,   150,   150,
     151,   151,   151,   151,   151,   151,   151,   151,   151,   151,
     151,   152,   152,   153,   153,   153,   153,   154,   155,   155,
     155,   155,   156,   155,   157,   155,   155,   155,   158,   158,
     159,   159,   159,   159,   159,   159,   159,   160,   160,   160,
     160,   160,   160,   161,   161,   162,   162,   162,   162,   163,
     163,   163,   164,   164,   164,   165,   165,   165,   165,   165,
     166,   166,   166,   167,   167,   168,   168,   169,   169,   170,
     171,   170,   172,   173,   172,   174,   175,   174,   176,   176,
     177,   177,   177,   177,   177,   177,   177,   177,   177,   177,
     177,   178,   179,   178,   180,   181,   181,   182,   182,   182,
     182,   183,   183,   184,   184,   185,   185,   185,   185,   185,
     186,   186,   187,   187,   188,   188,   188,   188,   188,   188,
     188,   188,   188,   188,   188,   188,   188,   188,   188,   188,
     188,   188,   188,   188,   188,   188,   189,   189,   190,   190,
     190,   190,   192,   191,   191,   193,   193,   194,   194,   195,
     196,   196,   197,   198,   198,   199,   199,   199,   199,   200,
     200,   200,   201,   201,   201,   202,   203,   203,   204,   204,
     205,   205,   206,   206,   207,   207,   208,   208,   208,   208,
     209,   210,   209,   209,   211,   211,   211,   211,   212,   213,
     213,   214,   214,   215,   215,   216,   216,   217,   217,   218,
     218,   219,   219,   220,   220,   220,   221,   221,   221,   221,
     221,   221,   221,   221,   222,   221,   223,   223,   223,   224,
     224,   225,   225,   225,   225,   225,   225,   225,   225,   226,
     227,   228,   228,   229,   228,   230,   231,   232,   232,   233,
     232,   234,   232,   232,   235,   235,   236,   236,   237,   237,
     238,   238,   240,   239,   241,   239,   242,   243,   244,   246,
     245,   245,   245,   247,   247,   248,   248,   248,   248,   248,
     249
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     2,     1,     1,     2,     3,     1,     2,
       2,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     1,     1,     3,     1,     1,     4,
       3,     4,     0,     4,     0,     4,     2,     2,     1,     3,
       1,     2,     2,     2,     2,     4,     2,     1,     1,     1,
       1,     1,     1,     1,     4,     1,     3,     3,     3,     1,
       3,     3,     1,     3,     3,     1,     3,     3,     3,     3,
       1,     3,     3,     1,     3,     1,     3,     1,     3,     1,
       0,     4,     1,     0,     4,     1,     0,     6,     1,     3,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     0,     4,     1,     2,     3,     1,     2,     1,
       2,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       1,     2,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       1,     1,     0,     6,     2,     1,     1,     1,     0,     1,
       1,     2,     3,     1,     3,     1,     2,     3,     0,     4,
       5,     2,     1,     2,     3,     2,     2,     0,     1,     2,
       1,     1,     1,     2,     1,     2,     1,     3,     3,     4,
       3,     0,     5,     4,     1,     2,     2,     3,     1,     1,
       2,     1,     3,     1,     3,     1,     3,     1,     3,     2,
       1,     1,     2,     1,     1,     2,     3,     2,     3,     3,
       4,     2,     3,     3,     0,     5,     1,     3,     4,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     2,     1,
       2,     2,     3,     0,     3,     1,     1,     2,     3,     0,
       4,     0,     5,     2,     1,     2,     1,     2,     1,     2,
       2,     0,     0,     7,     0,     6,     1,     1,     1,     0,
       6,     7,     9,     0,     1,     3,     2,     2,     2,     3,
       1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned short int yydefact[] =
{
       0,   280,   144,   115,   116,   117,   118,   119,   136,   137,
     148,   150,   151,   146,   135,   138,   139,   140,   124,   125,
     126,   127,   128,   129,   133,   134,   131,   132,   130,   141,
     155,   156,     0,     0,   198,     0,     2,     4,     5,     0,
     107,   109,   122,   145,   147,   142,   158,   143,     0,     0,
     182,   181,   184,     0,   194,   186,   149,     0,   171,     0,
     178,   180,     0,     1,     3,   105,     0,   111,   113,     0,
       0,   108,   110,     0,   152,   154,   159,     0,     0,   245,
       6,   254,     0,     0,    21,     0,   191,   120,    11,     0,
      12,    16,    19,    17,    18,    13,    14,    15,   185,     8,
      20,   183,   199,   196,   195,     0,   172,   177,     0,   187,
     179,     0,   106,     0,     7,    24,    27,     0,     0,     0,
       0,     0,    47,    48,    49,    50,    51,    52,    28,    25,
      40,    53,     0,    55,    59,    62,    65,    70,    73,    75,
      77,    79,    82,    85,   104,   123,    23,     0,   188,     0,
     253,   239,     0,   243,     0,     0,   266,   267,   268,     0,
       0,     0,     0,     0,   258,   246,    55,    88,   101,     0,
     256,     0,   237,   231,   247,   232,   251,     0,   233,   234,
       0,     0,     0,   235,   236,    23,   255,    22,   190,     0,
       0,   201,   203,   121,    10,     9,   200,   197,   173,   169,
       0,   175,     0,   112,     0,   226,   114,     0,    44,     0,
      46,    41,    42,     0,   211,     0,    34,    36,    37,     0,
       0,    32,    43,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    80,
      83,    86,     0,   189,     0,     0,     0,     0,     0,   276,
     277,   278,     0,   238,    91,    92,    93,    94,    95,    96,
      97,    98,    99,   100,    90,     0,   102,   259,   240,     0,
       0,   257,   248,     0,     0,   273,   241,   211,     0,   205,
     207,   210,   193,     0,   174,   176,   170,   229,     0,     0,
      26,     0,     0,   213,   212,   214,     0,     0,    30,     0,
      38,     0,     0,    56,    57,    58,    60,    61,    63,    64,
      68,    69,    66,    67,    71,    72,    74,    76,    78,     0,
       0,     0,     0,   160,   168,   242,   244,     0,     0,   275,
     279,    89,     0,   250,     0,     0,     0,   274,     0,     0,
     209,   213,   192,     0,   202,   204,     0,   227,    45,   221,
       0,     0,   217,     0,   215,   224,     0,    54,    35,    31,
       0,    29,    33,    81,    84,     0,   153,   161,     0,     0,
     163,   165,   262,   264,   103,   252,   269,     0,   273,   206,
     208,   228,   230,   222,   216,   218,   223,     0,   219,     0,
      39,     0,   166,   168,   162,     0,     0,     0,     0,     0,
       0,     0,   220,    87,   164,   167,   261,   265,   270,     0,
     273,   225,     0,   263,   271,     0,   260,     0,   272
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,    35,    36,    37,    98,    99,    80,   128,   129,   130,
     302,   297,   299,   131,   132,   166,   134,   135,   136,   137,
     138,   139,   140,   141,   142,   319,   143,   320,   167,   321,
     168,   265,   169,   332,   145,    81,    82,    66,    67,    40,
     100,   102,    42,    43,    44,    45,   147,    46,    74,    75,
     322,   323,   369,   370,    47,   105,   106,   201,    68,    60,
      49,    61,    51,    52,   189,    62,    54,   277,   190,   191,
     350,   279,   280,   281,   294,   295,   387,   206,   288,   170,
     171,   172,   173,   245,    83,   174,   175,   269,   270,    85,
     177,   178,   413,   179,   396,   397,   180,   181,   182,   183,
     398,   338,   184,   146
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -336
static const short int yypact[] =
{
    1257,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
      -1,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -336,    11,    25,  -336,  1211,  -336,  -336,  -336,    23,
    1545,  1545,    39,  -336,  -336,  -336,    53,  -336,   -35,   622,
     -10,   -27,   518,    31,  1487,  -336,  -336,    53,   -43,    49,
     -35,  -336,    31,  -336,  -336,  -336,   -31,  -336,   -29,   622,
      31,  -336,  -336,  1068,  -336,    46,  -336,   861,    32,  -336,
    -336,  -336,    23,   415,  -336,   622,    28,  1068,  -336,  1068,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,   518,
    -336,   -10,  -336,  -336,  1487,   -85,  -336,    62,    53,  -336,
     -35,    25,  -336,   778,  -336,  -336,  -336,  1095,  1107,  1107,
    1107,   964,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
      83,  -336,  1068,  -336,    45,    55,   131,    33,   183,    78,
      70,    75,   200,     1,  -336,  -336,  -336,    77,  -336,    97,
    -336,  -336,  1068,  -336,   101,   103,  -336,  -336,  -336,    53,
      86,    89,   186,    90,  -336,  -336,   102,  -336,  -336,    -9,
    -336,   693,  -336,  -336,  -336,  -336,   689,   506,  -336,  -336,
     104,   693,   113,  -336,  -336,    96,  -336,  -336,  -336,  1619,
     118,   116,  -336,  -336,  -336,  -336,  -336,  -336,    53,  -336,
    1068,  -336,   -78,  -336,   778,  -336,  -336,   964,  -336,  1068,
    -336,  -336,  -336,   -69,  1441,   123,  -336,  -336,  -336,  1032,
    1068,  -336,  -336,  1068,  1068,  1068,  1068,  1068,  1068,  1068,
    1068,  1068,  1068,  1068,  1068,  1068,  1068,  1068,  1068,  -336,
    -336,  -336,  1619,  -336,   106,   108,  1068,  1068,   109,  -336,
    -336,  -336,    15,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  1068,  -336,  -336,  -336,   110,
     693,  -336,  -336,  1068,   172,  1068,  -336,  1349,   130,   137,
    -336,  -336,  -336,    13,  -336,  -336,  -336,  -336,   -39,   134,
    -336,  1395,  1044,   -61,  -336,   -56,  1068,    53,  -336,   135,
     138,    37,    53,  -336,  -336,  -336,    45,    45,    55,    55,
     131,   131,   131,   131,    33,    33,   183,    78,    70,  1068,
    1068,  1068,   793,  -336,   885,  -336,  -336,   -20,    -7,  -336,
    -336,  -336,  1068,  -336,   506,    60,   144,   142,   133,  1303,
    -336,    26,  -336,  1582,  -336,  -336,   396,  -336,  -336,  -336,
     155,   157,  -336,   156,   -56,   161,  1056,  -336,  -336,  -336,
    1068,  -336,  -336,    75,   200,    -2,  -336,  -336,  1068,    30,
    -336,   145,  -336,  -336,  -336,  -336,  -336,  1068,  1068,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  1619,  -336,   160,
    -336,  1068,  -336,    27,  -336,  1068,   693,   693,   693,    61,
     146,   164,  -336,  -336,  -336,  -336,   211,  -336,  -336,   150,
    1068,  -336,   693,  -336,  -336,   167,  -336,   693,  -336
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
    -336,  -336,   260,  -336,   199,  -336,   232,  -336,  -336,  -336,
    -336,  -336,   -55,   143,  -336,   147,   -24,   -18,    41,   -19,
      68,    72,    73,     3,    -8,  -336,   -11,  -336,   -65,  -336,
    -104,  -336,  -110,  -336,   -62,     6,    38,  -336,   209,  -336,
    -336,    36,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,     9,  -336,   -72,  -336,   215,   127,  -336,   -32,     2,
     288,   178,  -336,  -336,  -336,     5,  -336,   -47,  -336,  -336,
    -186,  -336,   -15,  -103,  -270,  -243,  -336,  -200,  -336,  -158,
    -336,  -336,  -336,  -336,  -336,  -167,    -4,  -336,  -336,   249,
      65,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -335,  -336,     0
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -250
static const short int yytable[] =
{
      55,    59,    48,   278,   287,    53,    38,   104,   144,   205,
     272,   213,   144,   268,     1,   149,     1,   240,   215,   271,
     240,   351,   144,   274,   144,   193,     1,   194,     1,     1,
       1,     1,    58,    55,     1,    55,    41,    48,    39,    55,
      53,    38,   198,   400,    70,    84,    76,   230,   231,   198,
     354,    56,   252,    55,   290,    48,     1,   107,   266,   103,
     199,   291,    55,   292,   110,    84,   355,   286,   356,   351,
      55,    41,   110,    39,   214,   415,    41,    41,    71,    72,
      73,   187,    55,   185,   344,    41,   192,   144,   346,    77,
     244,   186,   216,   217,   218,    86,   111,   213,   354,   213,
     205,   108,   333,   372,   289,    41,   347,   266,   107,   197,
     301,    55,   112,   113,  -180,   300,   373,  -180,   266,    41,
     266,    41,   254,   255,   256,   257,   258,   259,   260,   261,
     262,   263,  -180,  -180,   267,   144,   327,   328,   285,   391,
     196,   241,   266,   228,   229,    33,   382,    33,   339,    33,
     292,   188,    34,    33,    34,    57,    34,   393,   330,   248,
     214,   331,   361,   335,   266,   337,    65,   375,   368,   232,
     233,   185,   109,   394,   223,   150,   271,   185,    50,   224,
     225,   185,   186,   376,   409,   226,   227,   266,   266,     1,
    -157,   115,   116,   117,   118,   324,   119,   120,   107,   234,
     235,   401,   306,   307,   200,   219,   236,   220,   237,   221,
     308,   309,    41,    50,   238,   314,   315,    50,   239,   293,
     133,   242,   243,   246,   133,   247,   273,   144,   374,   249,
     353,   101,   250,   253,   133,   275,   133,   276,   406,   407,
     408,   282,   205,   283,   264,   340,   296,   325,   101,   326,
     196,   336,   329,   342,   416,   165,   300,   348,   359,   418,
     208,   210,   211,   212,   343,   360,   377,   399,   337,   266,
     185,   310,   311,   312,   313,   324,   378,    55,   383,   222,
     384,   385,   341,   345,   386,   402,   395,   411,   412,   410,
     417,   144,   371,   414,   389,    64,   293,   358,   195,   133,
     337,   114,   362,   144,   316,   390,   392,    59,   121,   317,
     365,   318,   364,   196,   122,   123,   124,   125,   126,   127,
     203,   404,   363,   202,    55,   284,   403,    69,   380,   251,
     144,   367,   176,   405,   185,   334,     0,     0,     0,    55,
       0,    55,     0,   110,   341,     0,     0,   133,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     196,   371,     0,     0,     0,     0,     0,     0,     0,     0,
     303,   304,   305,   133,   133,   133,   133,   133,   133,   133,
     133,   133,   133,   133,   133,   133,     0,     0,     0,     0,
       0,     0,     0,    55,     0,     0,   185,   185,   185,     1,
       0,   115,   116,   117,   118,     0,   119,   120,     0,     0,
       0,     0,   185,     0,     0,     0,    78,   185,     1,     2,
     115,   116,   117,   118,     0,   119,   120,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   133,
       0,     0,     0,   357,     0,     3,     4,     5,     6,     7,
       8,     9,     0,    10,    11,    12,     0,    13,     0,     0,
      14,    15,    16,    17,     0,   151,   133,   133,   133,     0,
      18,    19,    20,    21,    22,    23,    24,     0,    25,    26,
      27,    28,    29,    30,    31,    32,     0,     0,     0,   152,
     153,   154,     0,   155,   156,   157,   158,   159,   160,   161,
     162,     0,     0,   133,   163,     0,     0,    78,     0,     1,
       0,   115,   116,   117,   118,   133,   119,   120,   121,     0,
       0,     0,     0,     0,   122,   123,   124,   125,   126,   127,
       0,     0,     0,     0,     0,     0,     0,   121,   133,     0,
     204,   381,   133,   122,   123,   124,   125,   126,   127,     0,
       0,     0,     0,     0,     0,    87,   151,     0,   164,    79,
     165,    88,    89,     0,     0,     0,     0,     0,    90,    91,
      92,    93,    94,     0,     0,     0,     0,     0,     0,     0,
     152,   153,   154,     0,   155,   156,   157,   158,   159,   160,
     161,   162,     0,     0,     0,   163,     0,     0,     0,     0,
       0,     0,     0,     0,    95,    96,    97,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    78,     0,     0,     2,     0,   121,     0,
       0,     0,     0,     0,   122,   123,   124,   125,   126,   127,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   164,
      79,   165,     3,     4,     5,     6,     7,     8,     9,     0,
      10,    11,    12,     0,    13,     0,     0,    14,    15,    16,
      17,     0,     0,     0,     0,     0,     0,    18,    19,    20,
      21,    22,    23,    24,     0,    25,    26,    27,    28,    29,
      30,    31,    32,     2,    78,     0,     1,     0,   115,   116,
     117,   118,     0,   119,   120,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     3,
       4,     5,     6,     7,     8,     9,     0,    10,    11,    12,
       0,    13,     0,     0,    14,    15,    16,    17,     0,     0,
       0,     0,     0,   151,    18,    19,    20,    21,    22,    23,
      24,     0,    25,    26,    27,    28,    29,    30,    31,    32,
       0,     0,     0,     0,     0,     0,    79,   152,   153,   154,
       0,   155,   156,   157,   158,   159,   160,   161,   162,     0,
       0,     1,   163,   115,   116,   117,   118,     0,   119,   120,
       0,     0,     0,     0,     0,     0,     0,     2,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   121,     0,     0,     0,     0,
       0,   122,   123,   124,   125,   126,   127,     0,     8,     9,
       0,    10,    11,    12,  -249,    13,   164,    79,    14,    15,
      16,    17,     0,     0,     0,     0,     0,     0,    18,    19,
      20,    21,    22,    23,    24,     0,    25,    26,    27,    28,
      29,    30,    31,    32,     1,     0,   115,   116,   117,   118,
       0,   119,   120,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     1,     2,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     121,     0,     0,     0,     0,     0,   122,   123,   124,   125,
     126,   127,     0,     0,     0,     0,     0,     0,     0,     0,
       8,     9,   204,    10,    11,    12,     0,    13,     0,     0,
      14,    15,    16,    17,     0,     0,     0,     0,   366,     0,
      18,    19,    20,    21,    22,    23,    24,     0,    25,    26,
      27,    28,    29,    30,    31,    32,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     1,     2,   115,
     116,   117,   118,     0,   119,   120,     0,     0,     0,     0,
       0,     0,     0,   121,     0,     0,   148,     0,     0,   122,
     123,   124,   125,   126,   127,     0,     0,     0,     0,     8,
       9,     0,    10,    11,    12,     0,    13,    33,     0,    14,
      15,    16,    17,     0,    34,     0,     0,     0,     0,    18,
      19,    20,    21,    22,    23,    24,   368,    25,    26,    27,
      28,    29,    30,    31,    32,     1,     0,   115,   116,   117,
     118,     0,   119,   120,     0,     0,     0,     1,     0,   115,
     116,   117,   118,     0,   119,   120,     0,     0,     0,     1,
       0,   115,   116,   117,   118,     0,   119,   120,     0,     0,
       0,     1,     0,   115,   116,   117,   118,     0,   119,   120,
       0,     0,     0,     0,     0,     0,   121,     0,     0,     0,
       0,     0,   122,   123,   124,   125,   126,   127,     1,     0,
     115,   116,   117,   118,     0,   119,   120,     0,     0,     0,
       1,     0,   115,   116,   117,   118,     0,   119,   120,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   121,   298,     0,     0,     0,     0,
     122,   123,   124,   125,   126,   127,   121,     0,     0,   352,
       0,     0,   122,   123,   124,   125,   126,   127,   121,     0,
       0,   388,     0,     0,   122,   123,   124,   125,   126,   127,
     121,     0,     0,     0,     0,     0,   122,   123,   124,   125,
     126,   127,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    63,     0,     0,     1,     2,     0,   207,     0,     0,
       0,     0,     0,   122,   123,   124,   125,   126,   127,   209,
       0,     0,     0,     0,     0,   122,   123,   124,   125,   126,
     127,     3,     4,     5,     6,     7,     8,     9,     0,    10,
      11,    12,     0,    13,     0,     0,    14,    15,    16,    17,
       1,     2,     0,     0,     0,     0,    18,    19,    20,    21,
      22,    23,    24,     0,    25,    26,    27,    28,    29,    30,
      31,    32,     0,     0,     0,     0,     0,     3,     4,     5,
       6,     7,     8,     9,     0,    10,    11,    12,     0,    13,
       0,     0,    14,    15,    16,    17,     1,     2,     0,     0,
       0,     0,    18,    19,    20,    21,    22,    23,    24,     0,
      25,    26,    27,    28,    29,    30,    31,    32,     0,     0,
       0,     0,     0,    33,     0,     0,     0,     0,     8,     9,
      34,    10,    11,    12,     0,    13,     0,     0,    14,    15,
      16,    17,     1,     2,     0,     0,     0,     0,    18,    19,
      20,    21,    22,    23,    24,     0,    25,    26,    27,    28,
      29,    30,    31,    32,     0,     0,     0,     0,     0,    33,
       0,     0,     0,     0,     8,     9,    34,    10,    11,    12,
       0,    13,     0,     0,    14,    15,    16,    17,     0,     2,
       0,     0,     0,     0,    18,    19,    20,    21,    22,    23,
      24,     0,    25,    26,    27,    28,    29,    30,    31,    32,
       0,     0,     0,     0,     0,   339,   349,   292,     0,     0,
       8,     9,    34,    10,    11,    12,     0,    13,     0,     0,
      14,    15,    16,    17,     0,     2,     0,     0,     0,     0,
      18,    19,    20,    21,    22,    23,    24,     0,    25,    26,
      27,    28,    29,    30,    31,    32,     0,     0,     0,     0,
       0,   339,     0,   292,     0,     0,     8,     9,    34,    10,
      11,    12,     0,    13,     0,     0,    14,    15,    16,    17,
       0,     2,     0,     0,     0,     0,    18,    19,    20,    21,
      22,    23,    24,     0,    25,    26,    27,    28,    29,    30,
      31,    32,     0,     0,     0,     0,     0,   291,   349,   292,
       0,     0,     8,     9,    34,    10,    11,    12,     0,    13,
       0,     0,    14,    15,    16,    17,     0,     0,     0,     0,
       0,     0,    18,    19,    20,    21,    22,    23,    24,     2,
      25,    26,    27,    28,    29,    30,    31,    32,     0,     0,
       0,     0,     0,   291,     0,   292,     0,     0,     0,     0,
      34,     0,     0,     0,     0,     3,     4,     5,     6,     7,
       8,     9,     0,    10,    11,    12,     2,    13,     0,     0,
      14,    15,    16,    17,     0,     0,     0,     0,     0,     0,
      18,    19,    20,    21,    22,    23,    24,     0,    25,    26,
      27,    28,    29,    30,    31,    32,    34,     8,     9,     0,
      10,    11,    12,     2,    13,     0,     0,    14,    15,    16,
      17,   379,     0,     0,     0,     0,     0,    18,    19,    20,
      21,    22,    23,    24,     0,    25,    26,    27,    28,    29,
      30,    31,    32,     0,     8,     9,     0,    10,    11,    12,
       0,    13,     0,     0,    14,    15,    16,    17,     0,     0,
       0,     0,     0,     0,    18,    19,    20,    21,    22,    23,
      24,     0,    25,    26,    27,    28,    29,    30,    31,    32
};

static const short int yycheck[] =
{
       0,    33,     0,   189,   204,     0,     0,    54,    73,   113,
     177,   121,    77,   171,     3,    77,     3,    19,   121,   177,
      19,   291,    87,   181,    89,    87,     3,    89,     3,     3,
       3,     3,    32,    33,     3,    35,     0,    35,     0,    39,
      35,    35,   127,   378,    39,    49,    46,    14,    15,   127,
     293,    52,   162,    53,   123,    53,     3,    57,   127,    54,
     145,   122,    62,   124,    62,    69,   122,   145,   124,   339,
      70,    35,    70,    35,   121,   410,    40,    41,    40,    41,
      41,    85,    82,    83,    71,    49,    86,   152,   127,   124,
     152,    85,     9,    10,    11,   122,   127,   207,   341,   209,
     204,   144,   269,   123,   207,    69,   145,   127,   108,   104,
     220,   111,   143,   142,   124,   219,   123,   127,   127,    83,
     127,    85,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,   142,   143,   143,   200,   246,   247,   200,   141,
     104,   140,   127,    12,    13,   122,   346,   122,   122,   122,
     124,   123,   129,   122,   129,   144,   129,   127,   143,   159,
     207,   265,   125,   273,   127,   275,   143,   334,   141,   136,
     137,   171,   123,   143,   129,   143,   334,   177,     0,   134,
     135,   181,   176,   123,   123,   130,   131,   127,   127,     3,
     144,     5,     6,     7,     8,   242,    10,    11,   198,    16,
      17,   387,   226,   227,   142,   122,   128,   124,   138,   126,
     228,   229,   176,    35,   139,   234,   235,    39,    18,   214,
      73,   144,   125,   122,    77,   122,   122,   292,   332,   143,
     292,    53,   143,   143,    87,   122,    89,   141,   396,   397,
     398,   123,   346,   127,   142,   277,   123,   141,    70,   141,
     214,    79,   143,   123,   412,   145,   360,   123,   123,   417,
     117,   118,   119,   120,   127,   127,   122,   377,   378,   127,
     270,   230,   231,   232,   233,   322,   143,   277,   123,   132,
     123,   125,   277,   283,   123,   125,   141,   123,    77,   143,
     123,   356,   324,   143,   356,    35,   291,   297,    99,   152,
     410,    69,   302,   368,   236,   360,   368,   339,   122,   237,
     321,   238,   320,   277,   128,   129,   130,   131,   132,   133,
     111,   393,   319,   108,   324,   198,   391,    39,   343,   143,
     395,   322,    83,   395,   334,   270,    -1,    -1,    -1,   339,
      -1,   341,    -1,   341,   339,    -1,    -1,   200,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     324,   393,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     223,   224,   225,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   236,   237,   238,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   393,    -1,    -1,   396,   397,   398,     3,
      -1,     5,     6,     7,     8,    -1,    10,    11,    -1,    -1,
      -1,    -1,   412,    -1,    -1,    -1,     1,   417,     3,     4,
       5,     6,     7,     8,    -1,    10,    11,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   292,
      -1,    -1,    -1,   296,    -1,    30,    31,    32,    33,    34,
      35,    36,    -1,    38,    39,    40,    -1,    42,    -1,    -1,
      45,    46,    47,    48,    -1,    50,   319,   320,   321,    -1,
      55,    56,    57,    58,    59,    60,    61,    -1,    63,    64,
      65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    74,
      75,    76,    -1,    78,    79,    80,    81,    82,    83,    84,
      85,    -1,    -1,   356,    89,    -1,    -1,     1,    -1,     3,
      -1,     5,     6,     7,     8,   368,    10,    11,   122,    -1,
      -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,   133,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   122,   391,    -1,
     144,   145,   395,   128,   129,   130,   131,   132,   133,    -1,
      -1,    -1,    -1,    -1,    -1,    37,    50,    -1,   143,   144,
     145,    43,    44,    -1,    -1,    -1,    -1,    -1,    50,    51,
      52,    53,    54,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      74,    75,    76,    -1,    78,    79,    80,    81,    82,    83,
      84,    85,    -1,    -1,    -1,    89,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    86,    87,    88,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     1,    -1,    -1,     4,    -1,   122,    -1,
      -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,   133,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   143,
     144,   145,    30,    31,    32,    33,    34,    35,    36,    -1,
      38,    39,    40,    -1,    42,    -1,    -1,    45,    46,    47,
      48,    -1,    -1,    -1,    -1,    -1,    -1,    55,    56,    57,
      58,    59,    60,    61,    -1,    63,    64,    65,    66,    67,
      68,    69,    70,     4,     1,    -1,     3,    -1,     5,     6,
       7,     8,    -1,    10,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,
      31,    32,    33,    34,    35,    36,    -1,    38,    39,    40,
      -1,    42,    -1,    -1,    45,    46,    47,    48,    -1,    -1,
      -1,    -1,    -1,    50,    55,    56,    57,    58,    59,    60,
      61,    -1,    63,    64,    65,    66,    67,    68,    69,    70,
      -1,    -1,    -1,    -1,    -1,    -1,   144,    74,    75,    76,
      -1,    78,    79,    80,    81,    82,    83,    84,    85,    -1,
      -1,     3,    89,     5,     6,     7,     8,    -1,    10,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     4,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   122,    -1,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,   133,    -1,    35,    36,
      -1,    38,    39,    40,   145,    42,   143,   144,    45,    46,
      47,    48,    -1,    -1,    -1,    -1,    -1,    -1,    55,    56,
      57,    58,    59,    60,    61,    -1,    63,    64,    65,    66,
      67,    68,    69,    70,     3,    -1,     5,     6,     7,     8,
      -1,    10,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,     4,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     122,    -1,    -1,    -1,    -1,    -1,   128,   129,   130,   131,
     132,   133,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      35,    36,   144,    38,    39,    40,    -1,    42,    -1,    -1,
      45,    46,    47,    48,    -1,    -1,    -1,    -1,   145,    -1,
      55,    56,    57,    58,    59,    60,    61,    -1,    63,    64,
      65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,
       6,     7,     8,    -1,    10,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   122,    -1,    -1,   125,    -1,    -1,   128,
     129,   130,   131,   132,   133,    -1,    -1,    -1,    -1,    35,
      36,    -1,    38,    39,    40,    -1,    42,   122,    -1,    45,
      46,    47,    48,    -1,   129,    -1,    -1,    -1,    -1,    55,
      56,    57,    58,    59,    60,    61,   141,    63,    64,    65,
      66,    67,    68,    69,    70,     3,    -1,     5,     6,     7,
       8,    -1,    10,    11,    -1,    -1,    -1,     3,    -1,     5,
       6,     7,     8,    -1,    10,    11,    -1,    -1,    -1,     3,
      -1,     5,     6,     7,     8,    -1,    10,    11,    -1,    -1,
      -1,     3,    -1,     5,     6,     7,     8,    -1,    10,    11,
      -1,    -1,    -1,    -1,    -1,    -1,   122,    -1,    -1,    -1,
      -1,    -1,   128,   129,   130,   131,   132,   133,     3,    -1,
       5,     6,     7,     8,    -1,    10,    11,    -1,    -1,    -1,
       3,    -1,     5,     6,     7,     8,    -1,    10,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   122,   123,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,   133,   122,    -1,    -1,   125,
      -1,    -1,   128,   129,   130,   131,   132,   133,   122,    -1,
      -1,   125,    -1,    -1,   128,   129,   130,   131,   132,   133,
     122,    -1,    -1,    -1,    -1,    -1,   128,   129,   130,   131,
     132,   133,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     0,    -1,    -1,     3,     4,    -1,   122,    -1,    -1,
      -1,    -1,    -1,   128,   129,   130,   131,   132,   133,   122,
      -1,    -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,
     133,    30,    31,    32,    33,    34,    35,    36,    -1,    38,
      39,    40,    -1,    42,    -1,    -1,    45,    46,    47,    48,
       3,     4,    -1,    -1,    -1,    -1,    55,    56,    57,    58,
      59,    60,    61,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    -1,    -1,    -1,    -1,    -1,    30,    31,    32,
      33,    34,    35,    36,    -1,    38,    39,    40,    -1,    42,
      -1,    -1,    45,    46,    47,    48,     3,     4,    -1,    -1,
      -1,    -1,    55,    56,    57,    58,    59,    60,    61,    -1,
      63,    64,    65,    66,    67,    68,    69,    70,    -1,    -1,
      -1,    -1,    -1,   122,    -1,    -1,    -1,    -1,    35,    36,
     129,    38,    39,    40,    -1,    42,    -1,    -1,    45,    46,
      47,    48,     3,     4,    -1,    -1,    -1,    -1,    55,    56,
      57,    58,    59,    60,    61,    -1,    63,    64,    65,    66,
      67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,   122,
      -1,    -1,    -1,    -1,    35,    36,   129,    38,    39,    40,
      -1,    42,    -1,    -1,    45,    46,    47,    48,    -1,     4,
      -1,    -1,    -1,    -1,    55,    56,    57,    58,    59,    60,
      61,    -1,    63,    64,    65,    66,    67,    68,    69,    70,
      -1,    -1,    -1,    -1,    -1,   122,   123,   124,    -1,    -1,
      35,    36,   129,    38,    39,    40,    -1,    42,    -1,    -1,
      45,    46,    47,    48,    -1,     4,    -1,    -1,    -1,    -1,
      55,    56,    57,    58,    59,    60,    61,    -1,    63,    64,
      65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
      -1,   122,    -1,   124,    -1,    -1,    35,    36,   129,    38,
      39,    40,    -1,    42,    -1,    -1,    45,    46,    47,    48,
      -1,     4,    -1,    -1,    -1,    -1,    55,    56,    57,    58,
      59,    60,    61,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    -1,    -1,    -1,    -1,    -1,   122,   123,   124,
      -1,    -1,    35,    36,   129,    38,    39,    40,    -1,    42,
      -1,    -1,    45,    46,    47,    48,    -1,    -1,    -1,    -1,
      -1,    -1,    55,    56,    57,    58,    59,    60,    61,     4,
      63,    64,    65,    66,    67,    68,    69,    70,    -1,    -1,
      -1,    -1,    -1,   122,    -1,   124,    -1,    -1,    -1,    -1,
     129,    -1,    -1,    -1,    -1,    30,    31,    32,    33,    34,
      35,    36,    -1,    38,    39,    40,     4,    42,    -1,    -1,
      45,    46,    47,    48,    -1,    -1,    -1,    -1,    -1,    -1,
      55,    56,    57,    58,    59,    60,    61,    -1,    63,    64,
      65,    66,    67,    68,    69,    70,   129,    35,    36,    -1,
      38,    39,    40,     4,    42,    -1,    -1,    45,    46,    47,
      48,    49,    -1,    -1,    -1,    -1,    -1,    55,    56,    57,
      58,    59,    60,    61,    -1,    63,    64,    65,    66,    67,
      68,    69,    70,    -1,    35,    36,    -1,    38,    39,    40,
      -1,    42,    -1,    -1,    45,    46,    47,    48,    -1,    -1,
      -1,    -1,    -1,    -1,    55,    56,    57,    58,    59,    60,
      61,    -1,    63,    64,    65,    66,    67,    68,    69,    70
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,     3,     4,    30,    31,    32,    33,    34,    35,    36,
      38,    39,    40,    42,    45,    46,    47,    48,    55,    56,
      57,    58,    59,    60,    61,    63,    64,    65,    66,    67,
      68,    69,    70,   122,   129,   147,   148,   149,   181,   182,
     185,   187,   188,   189,   190,   191,   193,   200,   205,   206,
     207,   208,   209,   211,   212,   249,    52,   144,   249,   204,
     205,   207,   211,     0,   148,   143,   183,   184,   204,   206,
     211,   182,   182,    41,   194,   195,   249,   124,     1,   144,
     152,   181,   182,   230,   232,   235,   122,    37,    43,    44,
      50,    51,    52,    53,    54,    86,    87,    88,   150,   151,
     186,   207,   187,   211,   213,   201,   202,   249,   144,   123,
     205,   127,   143,   142,   152,     5,     6,     7,     8,    10,
      11,   122,   128,   129,   130,   131,   132,   133,   153,   154,
     155,   159,   160,   161,   162,   163,   164,   165,   166,   167,
     168,   169,   170,   172,   174,   180,   249,   192,   125,   180,
     143,    50,    74,    75,    76,    78,    79,    80,    81,    82,
      83,    84,    85,    89,   143,   145,   161,   174,   176,   178,
     225,   226,   227,   228,   231,   232,   235,   236,   237,   239,
     242,   243,   244,   245,   248,   249,   181,   232,   123,   210,
     214,   215,   249,   180,   180,   150,   187,   211,   127,   145,
     142,   203,   201,   184,   144,   176,   223,   122,   159,   122,
     159,   159,   159,   178,   213,   219,     9,    10,    11,   122,
     124,   126,   161,   129,   134,   135,   130,   131,    12,    13,
      14,    15,   136,   137,    16,    17,   128,   138,   139,    18,
      19,   140,   144,   125,   180,   229,   122,   122,   249,   143,
     143,   143,   178,   143,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,   142,   177,   127,   143,   225,   233,
     234,   225,   231,   122,   225,   122,   141,   213,   216,   217,
     218,   219,   123,   127,   202,   180,   145,   223,   224,   219,
     123,   122,   124,   211,   220,   221,   123,   157,   123,   158,
     176,   178,   156,   161,   161,   161,   162,   162,   163,   163,
     164,   164,   164,   164,   165,   165,   166,   167,   168,   171,
     173,   175,   196,   197,   213,   141,   141,   178,   178,   143,
     143,   176,   179,   231,   236,   178,    79,   178,   247,   122,
     204,   211,   123,   127,    71,   249,   127,   145,   123,   123,
     216,   220,   125,   180,   221,   122,   124,   161,   249,   123,
     127,   125,   249,   169,   170,   172,   145,   197,   141,   198,
     199,   204,   123,   123,   176,   231,   123,   122,   143,    49,
     218,   145,   223,   123,   123,   125,   123,   222,   125,   180,
     158,   141,   180,   127,   143,   141,   240,   241,   246,   178,
     247,   216,   125,   174,   199,   180,   225,   225,   225,   123,
     143,   123,    77,   238,   143,   247,   225,   123,   225
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (0)


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
              (Loc).first_line, (Loc).first_column,	\
              (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short int *bottom, short int *top)
#else
static void
yy_stack_print (bottom, top)
    short int *bottom;
    short int *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname[yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);


# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()
    ;
#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short int yyssa[YYINITDEPTH];
  short int *yyss = yyssa;
  short int *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short int *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short int *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a look-ahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to look-ahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 4:
#line 141 "SDCC.y"
    { 
                               blockNo=0;
                             }
    break;

  case 5:
#line 144 "SDCC.y"
    { 
			       ignoreTypedefType = 0;
			       if ((yyvsp[0].sym) && (yyvsp[0].sym)->type
				&& IS_FUNC((yyvsp[0].sym)->type))
			       {
 				   /* The only legal storage classes for 
				    * a function prototype (declaration)
				    * are extern and static. extern is the
				    * default. Thus, if this function isn't
				    * explicitly marked static, mark it
				    * extern.
				    */
				   if ((yyvsp[0].sym)->etype 
				    && IS_SPEC((yyvsp[0].sym)->etype)
				    && !SPEC_STAT((yyvsp[0].sym)->etype))
				   {
				   	SPEC_EXTR((yyvsp[0].sym)->etype) = 1;
				   }
			       }
                               addSymChain (&(yyvsp[0].sym));
                               allocVariables ((yyvsp[0].sym)) ;
			       cleanUpLevel (SymbolTab,1);
                             }
    break;

  case 6:
#line 170 "SDCC.y"
    {   /* function type not specified */
                                   /* assume it to be 'int'       */
                                   addDecl((yyvsp[-1].sym),0,newIntLink());
				   (yyval.asts) = createFunction((yyvsp[-1].sym),(yyvsp[0].asts)); 
                               }
    break;

  case 7:
#line 176 "SDCC.y"
    {   
				    pointerTypes((yyvsp[-1].sym)->type,copyLinkChain((yyvsp[-2].lnk)));
				    addDecl((yyvsp[-1].sym),0,(yyvsp[-2].lnk)); 
				    (yyval.asts) = createFunction((yyvsp[-1].sym),(yyvsp[0].asts));   
				}
    break;

  case 9:
#line 185 "SDCC.y"
    { (yyval.lnk) = mergeSpec((yyvsp[-1].lnk),(yyvsp[0].lnk),"function_attribute"); }
    break;

  case 10:
#line 189 "SDCC.y"
    {
                        (yyval.lnk) = newLink(SPECIFIER) ;
			FUNC_REGBANK((yyval.lnk)) = (int) floatFromVal(constExprValue((yyvsp[0].asts),TRUE));
                     }
    break;

  case 11:
#line 193 "SDCC.y"
    {  (yyval.lnk) = newLink (SPECIFIER);
			FUNC_ISREENT((yyval.lnk))=1;
                     }
    break;

  case 12:
#line 196 "SDCC.y"
    {  (yyval.lnk) = newLink (SPECIFIER);
			FUNC_ISCRITICAL((yyval.lnk)) = 1;
                     }
    break;

  case 13:
#line 199 "SDCC.y"
    {  (yyval.lnk) = newLink (SPECIFIER);
			FUNC_ISNAKED((yyval.lnk))=1;
                     }
    break;

  case 14:
#line 202 "SDCC.y"
    {  (yyval.lnk) = newLink (SPECIFIER);
			FUNC_ISJAVANATIVE((yyval.lnk))=1;
                     }
    break;

  case 15:
#line 205 "SDCC.y"
    {  (yyval.lnk) = newLink (SPECIFIER);
			FUNC_ISOVERLAY((yyval.lnk))=1;
                     }
    break;

  case 16:
#line 208 "SDCC.y"
    {(yyval.lnk) = newLink (SPECIFIER);
                        FUNC_NONBANKED((yyval.lnk)) = 1;
			if (FUNC_BANKED((yyval.lnk))) {
			    werror(W_BANKED_WITH_NONBANKED);
			}
                     }
    break;

  case 17:
#line 214 "SDCC.y"
    {(yyval.lnk) = newLink (SPECIFIER);
                        FUNC_ISSHADOWREGS((yyval.lnk)) = 1;
                     }
    break;

  case 18:
#line 217 "SDCC.y"
    {(yyval.lnk) = newLink (SPECIFIER);
                        FUNC_ISWPARAM((yyval.lnk)) = 1;
                     }
    break;

  case 19:
#line 220 "SDCC.y"
    {(yyval.lnk) = newLink (SPECIFIER);
                        FUNC_BANKED((yyval.lnk)) = 1;
			if (FUNC_NONBANKED((yyval.lnk))) {
			    werror(W_BANKED_WITH_NONBANKED);
			}
			if (SPEC_STAT((yyval.lnk))) {
			    werror(W_BANKED_WITH_STATIC);
			}
                     }
    break;

  case 20:
#line 230 "SDCC.y"
    {
                        (yyval.lnk) = newLink (SPECIFIER) ;
                        FUNC_INTNO((yyval.lnk)) = (yyvsp[0].yyint) ;
                        FUNC_ISISR((yyval.lnk)) = 1;
                     }
    break;

  case 22:
#line 240 "SDCC.y"
    {
            werror(E_OLD_STYLE,((yyvsp[-1].sym) ? (yyvsp[-1].sym)->name: "")) ;
	    exit(1);
         }
    break;

  case 23:
#line 247 "SDCC.y"
    {  (yyval.asts) = newAst_VALUE(symbolVal((yyvsp[0].sym)));  }
    break;

  case 24:
#line 248 "SDCC.y"
    {  (yyval.asts) = newAst_VALUE((yyvsp[0].val));  }
    break;

  case 26:
#line 250 "SDCC.y"
    {  (yyval.asts) = (yyvsp[-1].asts) ;                   }
    break;

  case 27:
#line 254 "SDCC.y"
    { (yyval.asts) = newAst_VALUE((yyvsp[0].val)); }
    break;

  case 29:
#line 259 "SDCC.y"
    { (yyval.asts) = newNode	('[', (yyvsp[-3].asts), (yyvsp[-1].asts)) ; }
    break;

  case 30:
#line 260 "SDCC.y"
    { (yyval.asts) = newNode  (CALL,(yyvsp[-2].asts),NULL); 
                                          (yyval.asts)->left->funcName = 1;}
    break;

  case 31:
#line 263 "SDCC.y"
    { 	   
	    (yyval.asts) = newNode  (CALL,(yyvsp[-3].asts),(yyvsp[-1].asts)) ; (yyval.asts)->left->funcName = 1;
	  }
    break;

  case 32:
#line 266 "SDCC.y"
    { ignoreTypedefType = 1; }
    break;

  case 33:
#line 267 "SDCC.y"
    {    
			ignoreTypedefType = 0;
			(yyvsp[0].sym) = newSymbol((yyvsp[0].sym)->name,NestLevel);
			(yyvsp[0].sym)->implicit = 1;
			(yyval.asts) = newNode(PTR_OP,newNode('&',(yyvsp[-3].asts),NULL),newAst_VALUE(symbolVal((yyvsp[0].sym))));
/* 			$$ = newNode('.',$1,newAst(EX_VALUE,symbolVal($4))) ;		        */
		      }
    break;

  case 34:
#line 274 "SDCC.y"
    { ignoreTypedefType = 1; }
    break;

  case 35:
#line 275 "SDCC.y"
    { 
			ignoreTypedefType = 0;
			(yyvsp[0].sym) = newSymbol((yyvsp[0].sym)->name,NestLevel);
			(yyvsp[0].sym)->implicit = 1;			
			(yyval.asts) = newNode(PTR_OP,(yyvsp[-3].asts),newAst_VALUE(symbolVal((yyvsp[0].sym))));
		      }
    break;

  case 36:
#line 282 "SDCC.y"
    {	(yyval.asts) = newNode(INC_OP,(yyvsp[-1].asts),NULL);}
    break;

  case 37:
#line 284 "SDCC.y"
    {	(yyval.asts) = newNode(DEC_OP,(yyvsp[-1].asts),NULL); }
    break;

  case 39:
#line 289 "SDCC.y"
    { (yyval.asts) = newNode(PARAM,(yyvsp[-2].asts),(yyvsp[0].asts)); }
    break;

  case 41:
#line 294 "SDCC.y"
    { (yyval.asts) = newNode(INC_OP,NULL,(yyvsp[0].asts));  }
    break;

  case 42:
#line 295 "SDCC.y"
    { (yyval.asts) = newNode(DEC_OP,NULL,(yyvsp[0].asts));  }
    break;

  case 43:
#line 296 "SDCC.y"
    { (yyval.asts) = newNode((yyvsp[-1].yyint),(yyvsp[0].asts),NULL)    ;  }
    break;

  case 44:
#line 297 "SDCC.y"
    { (yyval.asts) = newNode(SIZEOF,NULL,(yyvsp[0].asts));  }
    break;

  case 45:
#line 298 "SDCC.y"
    { (yyval.asts) = newAst_VALUE(sizeofOp((yyvsp[-1].lnk))); }
    break;

  case 46:
#line 299 "SDCC.y"
    { (yyval.asts) = newNode(TYPEOF,NULL,(yyvsp[0].asts));  }
    break;

  case 47:
#line 303 "SDCC.y"
    { (yyval.yyint) = '&' ;}
    break;

  case 48:
#line 304 "SDCC.y"
    { (yyval.yyint) = '*' ;}
    break;

  case 49:
#line 305 "SDCC.y"
    { (yyval.yyint) = '+' ;}
    break;

  case 50:
#line 306 "SDCC.y"
    { (yyval.yyint) = '-' ;}
    break;

  case 51:
#line 307 "SDCC.y"
    { (yyval.yyint) = '~' ;}
    break;

  case 52:
#line 308 "SDCC.y"
    { (yyval.yyint) = '!' ;}
    break;

  case 54:
#line 313 "SDCC.y"
    { (yyval.asts) = newNode(CAST,newAst_LINK((yyvsp[-2].lnk)),(yyvsp[0].asts)); }
    break;

  case 56:
#line 318 "SDCC.y"
    { (yyval.asts) = newNode('*',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 57:
#line 319 "SDCC.y"
    { (yyval.asts) = newNode('/',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 58:
#line 320 "SDCC.y"
    { (yyval.asts) = newNode('%',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 60:
#line 325 "SDCC.y"
    { (yyval.asts)=newNode('+',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 61:
#line 326 "SDCC.y"
    { (yyval.asts)=newNode('-',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 63:
#line 331 "SDCC.y"
    { (yyval.asts) = newNode(LEFT_OP,(yyvsp[-2].asts),(yyvsp[0].asts)); }
    break;

  case 64:
#line 332 "SDCC.y"
    { (yyval.asts) = newNode(RIGHT_OP,(yyvsp[-2].asts),(yyvsp[0].asts)); }
    break;

  case 66:
#line 337 "SDCC.y"
    { 
	(yyval.asts) = (port->lt_nge ? 
	      newNode('!',newNode(GE_OP,(yyvsp[-2].asts),(yyvsp[0].asts)),NULL) :
	      newNode('<', (yyvsp[-2].asts),(yyvsp[0].asts)));
   }
    break;

  case 67:
#line 342 "SDCC.y"
    { 
	   (yyval.asts) = (port->gt_nle ? 
		 newNode('!',newNode(LE_OP,(yyvsp[-2].asts),(yyvsp[0].asts)),NULL) :
		 newNode('>',(yyvsp[-2].asts),(yyvsp[0].asts)));
   }
    break;

  case 68:
#line 347 "SDCC.y"
    { 
	   (yyval.asts) = (port->le_ngt ? 
		 newNode('!', newNode('>', (yyvsp[-2].asts) , (yyvsp[0].asts) ), NULL) :
		 newNode(LE_OP,(yyvsp[-2].asts),(yyvsp[0].asts)));
   }
    break;

  case 69:
#line 352 "SDCC.y"
    { 
	   (yyval.asts) = (port->ge_nlt ? 
		 newNode('!', newNode('<', (yyvsp[-2].asts) , (yyvsp[0].asts) ), NULL) :
		 newNode(GE_OP,(yyvsp[-2].asts),(yyvsp[0].asts)));
   }
    break;

  case 71:
#line 361 "SDCC.y"
    { 
    (yyval.asts) = (port->eq_nne ? 
	  newNode('!',newNode(NE_OP,(yyvsp[-2].asts),(yyvsp[0].asts)),NULL) : 
	  newNode(EQ_OP,(yyvsp[-2].asts),(yyvsp[0].asts)));
   }
    break;

  case 72:
#line 366 "SDCC.y"
    { 
       (yyval.asts) = (port->ne_neq ? 
	     newNode('!', newNode(EQ_OP,(yyvsp[-2].asts),(yyvsp[0].asts)), NULL) : 
	     newNode(NE_OP,(yyvsp[-2].asts),(yyvsp[0].asts)));
   }
    break;

  case 74:
#line 375 "SDCC.y"
    { (yyval.asts) = newNode('&',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 76:
#line 380 "SDCC.y"
    { (yyval.asts) = newNode('^',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 78:
#line 385 "SDCC.y"
    { (yyval.asts) = newNode('|',(yyvsp[-2].asts),(yyvsp[0].asts));}
    break;

  case 80:
#line 390 "SDCC.y"
    { seqPointNo++;}
    break;

  case 81:
#line 391 "SDCC.y"
    { (yyval.asts) = newNode(AND_OP,(yyvsp[-3].asts),(yyvsp[0].asts));}
    break;

  case 83:
#line 396 "SDCC.y"
    { seqPointNo++;}
    break;

  case 84:
#line 397 "SDCC.y"
    { (yyval.asts) = newNode(OR_OP,(yyvsp[-3].asts),(yyvsp[0].asts)); }
    break;

  case 86:
#line 402 "SDCC.y"
    { seqPointNo++;}
    break;

  case 87:
#line 403 "SDCC.y"
    {
                        (yyval.asts) = newNode(':',(yyvsp[-2].asts),(yyvsp[0].asts)) ;
                        (yyval.asts) = newNode('?',(yyvsp[-5].asts),(yyval.asts)) ;
                     }
    break;

  case 89:
#line 412 "SDCC.y"
    { 
				 
			     switch ((yyvsp[-1].yyint)) {
			     case '=':
				     (yyval.asts) = newNode((yyvsp[-1].yyint),(yyvsp[-2].asts),(yyvsp[0].asts));
				     break;
			     case MUL_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('*',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case DIV_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('/',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case MOD_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('%',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case ADD_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('+',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case SUB_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('-',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case LEFT_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode(LEFT_OP,removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case RIGHT_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode(RIGHT_OP,removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case AND_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('&',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case XOR_ASSIGN:
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('^',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     case OR_ASSIGN:
				     /* $$ = newNode('=',$1,newNode('|',removeIncDecOps(copyAst($1)),$3)); */
				     (yyval.asts) = newNode('=',removePostIncDecOps(copyAst((yyvsp[-2].asts))),
                                                      newNode('|',removePreIncDecOps(copyAst((yyvsp[-2].asts))),(yyvsp[0].asts)));
				     break;
			     default :
				     (yyval.asts) = NULL;
			     }
				     
                     }
    break;

  case 90:
#line 467 "SDCC.y"
    { (yyval.yyint) = '=' ;}
    break;

  case 102:
#line 482 "SDCC.y"
    { seqPointNo++;}
    break;

  case 103:
#line 482 "SDCC.y"
    { (yyval.asts) = newNode(',',(yyvsp[-3].asts),(yyvsp[0].asts));}
    break;

  case 105:
#line 491 "SDCC.y"
    {
         if (uselessDecl)
           werror(W_USELESS_DECL);
         uselessDecl = TRUE;
         (yyval.sym) = NULL ;
      }
    break;

  case 106:
#line 498 "SDCC.y"
    {
         /* add the specifier list to the id */
         symbol *sym , *sym1;

         for (sym1 = sym = reverseSyms((yyvsp[-1].sym));sym != NULL;sym = sym->next) {
	     sym_link *lnk = copyLinkChain((yyvsp[-2].lnk));
	     /* do the pointer stuff */
	     pointerTypes(sym->type,lnk);
	     addDecl (sym,0,lnk) ;
	 }
        
         uselessDecl = TRUE;
	 (yyval.sym) = sym1 ;
      }
    break;

  case 107:
#line 515 "SDCC.y"
    { (yyval.lnk) = (yyvsp[0].lnk); }
    break;

  case 108:
#line 516 "SDCC.y"
    { 
     /* if the decl $2 is not a specifier */
     /* find the spec and replace it      */
     if ( !IS_SPEC((yyvsp[0].lnk))) {
       sym_link *lnk = (yyvsp[0].lnk) ;
       while (lnk && !IS_SPEC(lnk->next))
	 lnk = lnk->next;
       lnk->next = mergeSpec((yyvsp[-1].lnk),lnk->next, "storage_class_specifier declaration_specifiers - skipped");
       (yyval.lnk) = (yyvsp[0].lnk) ;
     }
     else
       (yyval.lnk) = mergeSpec((yyvsp[-1].lnk),(yyvsp[0].lnk), "storage_class_specifier declaration_specifiers");
   }
    break;

  case 109:
#line 529 "SDCC.y"
    { (yyval.lnk) = (yyvsp[0].lnk); }
    break;

  case 110:
#line 530 "SDCC.y"
    { 
     /* if the decl $2 is not a specifier */
     /* find the spec and replace it      */
     if ( !IS_SPEC((yyvsp[0].lnk))) {
       sym_link *lnk = (yyvsp[0].lnk) ;
       while (lnk && !IS_SPEC(lnk->next))
	 lnk = lnk->next;
       lnk->next = mergeSpec((yyvsp[-1].lnk),lnk->next, "type_specifier declaration_specifiers - skipped");
       (yyval.lnk) = (yyvsp[0].lnk) ;
     }
     else
       (yyval.lnk) = mergeSpec((yyvsp[-1].lnk),(yyvsp[0].lnk), "type_specifier declaration_specifiers");
   }
    break;

  case 112:
#line 547 "SDCC.y"
    { (yyvsp[0].sym)->next = (yyvsp[-2].sym) ; (yyval.sym) = (yyvsp[0].sym);}
    break;

  case 113:
#line 551 "SDCC.y"
    { (yyvsp[0].sym)->ival = NULL ; }
    break;

  case 114:
#line 552 "SDCC.y"
    { (yyvsp[-2].sym)->ival = (yyvsp[0].ilist)   ; }
    break;

  case 115:
#line 557 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER) ;
                  SPEC_TYPEDEF((yyval.lnk)) = 1 ;
               }
    break;

  case 116:
#line 561 "SDCC.y"
    {
                  (yyval.lnk) = newLink(SPECIFIER);
                  SPEC_EXTR((yyval.lnk)) = 1 ;
               }
    break;

  case 117:
#line 565 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER);
                  SPEC_STAT((yyval.lnk)) = 1 ;
               }
    break;

  case 118:
#line 569 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER) ;
                  SPEC_SCLS((yyval.lnk)) = S_AUTO  ;
               }
    break;

  case 119:
#line 573 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER);
                  SPEC_SCLS((yyval.lnk)) = S_REGISTER ;
               }
    break;

  case 120:
#line 580 "SDCC.y"
    { (yyval.yyint) = INTNO_UNSPEC ; }
    break;

  case 121:
#line 582 "SDCC.y"
    { int intno = (int) floatFromVal(constExprValue((yyvsp[0].asts),TRUE));
          if ((intno >= 0) && (intno <= INTNO_MAX))
            (yyval.yyint) = intno;
          else
            {
              werror(E_INT_BAD_INTNO, intno);
              (yyval.yyint) = INTNO_UNSPEC;
            }
        }
    break;

  case 123:
#line 596 "SDCC.y"
    {
	   /* add this to the storage class specifier  */
           SPEC_ABSA((yyvsp[-2].lnk)) = 1;   /* set the absolute addr flag */
           /* now get the abs addr from value */
           SPEC_ADDR((yyvsp[-2].lnk)) = (unsigned) floatFromVal(constExprValue((yyvsp[0].asts),TRUE)) ;
        }
    break;

  case 124:
#line 605 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_NOUN((yyval.lnk)) = V_CHAR  ;
                  ignoreTypedefType = 1;
               }
    break;

  case 125:
#line 610 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_SHORT((yyval.lnk)) = 1 ;
                  ignoreTypedefType = 1;
               }
    break;

  case 126:
#line 615 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_NOUN((yyval.lnk)) = V_INT   ;
                  ignoreTypedefType = 1;
               }
    break;

  case 127:
#line 620 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_LONG((yyval.lnk)) = 1       ;
                  ignoreTypedefType = 1;
               }
    break;

  case 128:
#line 625 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  (yyval.lnk)->select.s.b_signed = 1;
                  ignoreTypedefType = 1;
               }
    break;

  case 129:
#line 630 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_USIGN((yyval.lnk)) = 1      ;
                  ignoreTypedefType = 1;
               }
    break;

  case 130:
#line 635 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_NOUN((yyval.lnk)) = V_VOID  ;
                  ignoreTypedefType = 1;
               }
    break;

  case 131:
#line 640 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_CONST((yyval.lnk)) = 1;
               }
    break;

  case 132:
#line 644 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_VOLATILE((yyval.lnk)) = 1 ;
               }
    break;

  case 133:
#line 648 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_NOUN((yyval.lnk)) = V_FLOAT;
                  ignoreTypedefType = 1;
               }
    break;

  case 134:
#line 653 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_NOUN((yyval.lnk)) = V_FIXED16X16;
                  ignoreTypedefType = 1;
               }
    break;

  case 135:
#line 658 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER);
                  SPEC_SCLS((yyval.lnk)) = S_XDATA  ;
               }
    break;

  case 136:
#line 662 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER) ;
                  SPEC_SCLS((yyval.lnk)) = S_CODE ;                 
               }
    break;

  case 137:
#line 666 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER) ;
                  SPEC_SCLS((yyval.lnk)) = S_EEPROM ;
               }
    break;

  case 138:
#line 670 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER);
                  SPEC_SCLS((yyval.lnk)) = S_DATA   ;
               }
    break;

  case 139:
#line 674 "SDCC.y"
    {
                  (yyval.lnk) = newLink (SPECIFIER);
                  SPEC_SCLS((yyval.lnk)) = S_IDATA  ;
               }
    break;

  case 140:
#line 678 "SDCC.y"
    { 
                  (yyval.lnk) = newLink (SPECIFIER);
                  SPEC_SCLS((yyval.lnk)) = S_PDATA  ;
               }
    break;

  case 141:
#line 682 "SDCC.y"
    {
                  (yyval.lnk)=newLink(SPECIFIER);
                  SPEC_NOUN((yyval.lnk)) = V_BIT   ;
                  SPEC_SCLS((yyval.lnk)) = S_BIT   ;
                  SPEC_BLEN((yyval.lnk)) = 1;
                  SPEC_BSTR((yyval.lnk)) = 0;
                  ignoreTypedefType = 1;
               }
    break;

  case 142:
#line 691 "SDCC.y"
    {
                                   uselessDecl = FALSE;
                                   (yyval.lnk) = (yyvsp[0].lnk) ;
                                   ignoreTypedefType = 1;
                                }
    break;

  case 143:
#line 696 "SDCC.y"
    {                           
                           cenum = NULL ;
                           uselessDecl = FALSE;
                           ignoreTypedefType = 1;
                           (yyval.lnk) = (yyvsp[0].lnk) ;                              
                        }
    break;

  case 144:
#line 703 "SDCC.y"
    {
            symbol *sym;
            sym_link   *p  ;
            sym = findSym(TypedefTab,NULL,(yyvsp[0].yychar)) ;
            (yyval.lnk) = p = copyLinkChain(sym->type);
            SPEC_TYPEDEF(getSpec(p)) = 0;
            ignoreTypedefType = 1;
         }
    break;

  case 146:
#line 715 "SDCC.y"
    {
               (yyval.lnk) = newLink(SPECIFIER) ;
               SPEC_NOUN((yyval.lnk)) = V_SBIT;
               SPEC_SCLS((yyval.lnk)) = S_SBIT;
               SPEC_BLEN((yyval.lnk)) = 1;
               SPEC_BSTR((yyval.lnk)) = 0;
               ignoreTypedefType = 1;
            }
    break;

  case 148:
#line 727 "SDCC.y"
    {
               (yyval.lnk) = newLink(SPECIFIER) ;
               FUNC_REGBANK((yyval.lnk)) = 0;
               SPEC_NOUN((yyval.lnk))    = V_CHAR;
               SPEC_SCLS((yyval.lnk))    = S_SFR ;
               SPEC_USIGN((yyval.lnk))   = 1 ;
               ignoreTypedefType = 1;
            }
    break;

  case 149:
#line 735 "SDCC.y"
    {
               (yyval.lnk) = newLink(SPECIFIER) ;
               FUNC_REGBANK((yyval.lnk)) = 1;
               SPEC_NOUN((yyval.lnk))    = V_CHAR;
               SPEC_SCLS((yyval.lnk))    = S_SFR ;
               SPEC_USIGN((yyval.lnk))   = 1 ;
               ignoreTypedefType = 1;
            }
    break;

  case 150:
#line 746 "SDCC.y"
    {
               (yyval.lnk) = newLink(SPECIFIER) ;
               FUNC_REGBANK((yyval.lnk)) = 0;
               SPEC_NOUN((yyval.lnk))    = V_INT;
               SPEC_SCLS((yyval.lnk))    = S_SFR;
               SPEC_USIGN((yyval.lnk))   = 1 ;
               ignoreTypedefType = 1;
            }
    break;

  case 151:
#line 757 "SDCC.y"
    {
               (yyval.lnk) = newLink(SPECIFIER) ;
               FUNC_REGBANK((yyval.lnk)) = 0;
               SPEC_NOUN((yyval.lnk))    = V_INT;
               SPEC_SCLS((yyval.lnk))    = S_SFR;
               SPEC_LONG((yyval.lnk))    = 1;
               SPEC_USIGN((yyval.lnk))   = 1;
               ignoreTypedefType = 1;
            }
    break;

  case 152:
#line 770 "SDCC.y"
    {
           if (!(yyvsp[0].sdef)->type)
             {
               (yyvsp[0].sdef)->type = (yyvsp[-1].yyint);
             }
           else
             {
               if ((yyvsp[0].sdef)->type != (yyvsp[-1].yyint))
                 werror(E_BAD_TAG, (yyvsp[0].sdef)->tag, (yyvsp[-1].yyint)==STRUCT ? "struct" : "union");
             }

	}
    break;

  case 153:
#line 783 "SDCC.y"
    {
           structdef *sdef ;
	   symbol *sym, *dsym;

	   // check for errors in structure members
	   for (sym=(yyvsp[-1].sym); sym; sym=sym->next) {
	     if (IS_ABSOLUTE(sym->etype)) {
	       werrorfl(sym->fileDef, sym->lineDef, E_NOT_ALLOWED, "'at'");
	       SPEC_ABSA(sym->etype) = 0;
	     }
	     if (IS_SPEC(sym->etype) && SPEC_SCLS(sym->etype)) {
	       werrorfl(sym->fileDef, sym->lineDef, E_NOT_ALLOWED, "storage class");
	       printTypeChainRaw (sym->type,NULL);
	       SPEC_SCLS(sym->etype) = 0;
	     }
	     for (dsym=sym->next; dsym; dsym=dsym->next) {
	       if (*dsym->name && strcmp(sym->name, dsym->name)==0) {
		 werrorfl(sym->fileDef, sym->lineDef, E_DUPLICATE_MEMBER, 
			(yyvsp[-5].yyint)==STRUCT ? "struct" : "union", sym->name);
		 werrorfl(dsym->fileDef, dsym->lineDef, E_PREVIOUS_DEF);
	       }
	     }
	   }

           /* Create a structdef   */	   
           sdef = (yyvsp[-4].sdef) ;
           sdef->fields   = reverseSyms((yyvsp[-1].sym)) ;   /* link the fields */
           sdef->size  = compStructSize((yyvsp[-5].yyint),sdef);   /* update size of  */
	   promoteAnonStructs ((yyvsp[-5].yyint), sdef);
	   
           /* Create the specifier */
           (yyval.lnk) = newLink (SPECIFIER) ;
           SPEC_NOUN((yyval.lnk)) = V_STRUCT;
           SPEC_STRUCT((yyval.lnk))= sdef ;
        }
    break;

  case 154:
#line 819 "SDCC.y"
    {
            (yyval.lnk) = newLink(SPECIFIER) ;
            SPEC_NOUN((yyval.lnk)) = V_STRUCT;
            SPEC_STRUCT((yyval.lnk)) = (yyvsp[0].sdef);

           if (!(yyvsp[0].sdef)->type)
             {
               (yyvsp[0].sdef)->type = (yyvsp[-1].yyint);
             }
           else
             {
               if ((yyvsp[0].sdef)->type != (yyvsp[-1].yyint))
                 werror(E_BAD_TAG, (yyvsp[0].sdef)->tag, (yyvsp[-1].yyint)==STRUCT ? "struct" : "union");
             }
         }
    break;

  case 155:
#line 837 "SDCC.y"
    { (yyval.yyint) = STRUCT ; }
    break;

  case 156:
#line 838 "SDCC.y"
    { (yyval.yyint) = UNION  ; }
    break;

  case 158:
#line 843 "SDCC.y"
    {  /* synthesize a name add to structtable */
     (yyval.sdef) = newStruct(genSymName(NestLevel)) ;
     (yyval.sdef)->level = NestLevel ;
     addSym (StructTab, (yyval.sdef), (yyval.sdef)->tag,(yyval.sdef)->level,currBlockno, 0);
}
    break;

  case 159:
#line 850 "SDCC.y"
    {  /* add name to structure table */
     (yyval.sdef) = findSymWithBlock (StructTab,(yyvsp[0].sym),currBlockno);
     if (! (yyval.sdef) ) {
       (yyval.sdef) = newStruct((yyvsp[0].sym)->name) ;
       (yyval.sdef)->level = NestLevel ;
       addSym (StructTab, (yyval.sdef), (yyval.sdef)->tag,(yyval.sdef)->level,currBlockno,0);
     }
}
    break;

  case 161:
#line 863 "SDCC.y"
    {
	   symbol *sym=(yyvsp[0].sym);

	   /* go to the end of the chain */
	   while (sym->next) sym=sym->next;
           sym->next = (yyvsp[-1].sym) ;
	 
           (yyval.sym) = (yyvsp[0].sym);
       }
    break;

  case 162:
#line 876 "SDCC.y"
    {
           /* add this type to all the symbols */
           symbol *sym ;
           for ( sym = (yyvsp[-1].sym) ; sym != NULL ; sym = sym->next ) {
	       sym_link *btype = copyLinkChain((yyvsp[-2].lnk));
	       
	       /* make the symbol one level up */
	       sym->level-- ;

	       pointerTypes(sym->type,btype);
	       if (!sym->type) {
		   sym->type = btype;
		   sym->etype = getSpec(sym->type);
	       }
	       else
		 addDecl (sym,0,btype);
	       /* make sure the type is complete and sane */
	       checkTypeSanity(sym->etype, sym->name);
	   }
	   ignoreTypedefType = 0;
	   (yyval.sym) = (yyvsp[-1].sym);
       }
    break;

  case 164:
#line 903 "SDCC.y"
    {
           (yyvsp[0].sym)->next  = (yyvsp[-2].sym) ;
           (yyval.sym) = (yyvsp[0].sym) ;
       }
    break;

  case 166:
#line 911 "SDCC.y"
    {
                           unsigned int bitsize;
                           (yyval.sym) = newSymbol (genSymName(NestLevel),NestLevel) ; 
                           bitsize= (unsigned int) floatFromVal(constExprValue((yyvsp[0].asts),TRUE));
                           if (bitsize > (port->s.int_size * 8)) {
                             bitsize = port->s.int_size * 8;
                             werror(E_BITFLD_SIZE, bitsize);
                           }
                           if (!bitsize)
                             bitsize = BITVAR_PAD;
                           (yyval.sym)->bitVar = bitsize;
                        }
    break;

  case 167:
#line 924 "SDCC.y"
    {
                          unsigned int bitsize;
                          bitsize= (unsigned int) floatFromVal(constExprValue((yyvsp[0].asts),TRUE));
                          if (bitsize > (port->s.int_size * 8)) {
                            bitsize = port->s.int_size * 8;
                            werror(E_BITFLD_SIZE, bitsize);
                          }
                          if (!bitsize) {
                            (yyval.sym) = newSymbol (genSymName(NestLevel),NestLevel) ; 
                            (yyval.sym)->bitVar = BITVAR_PAD;
                            werror(W_BITFLD_NAMED);
                          }
			  else
			    (yyvsp[-2].sym)->bitVar = bitsize;
                        }
    break;

  case 168:
#line 939 "SDCC.y"
    { (yyval.sym) = newSymbol ("", NestLevel) ; }
    break;

  case 169:
#line 944 "SDCC.y"
    {
	   (yyval.lnk) = newEnumType ((yyvsp[-1].sym));	//copyLinkChain(cenum->type);
	   SPEC_SCLS(getSpec((yyval.lnk))) = 0;
         }
    break;

  case 170:
#line 949 "SDCC.y"
    {
     symbol *csym ;
     sym_link *enumtype;

     csym=findSym(enumTab,(yyvsp[-3].sym),(yyvsp[-3].sym)->name);
     if ((csym && csym->level == (yyvsp[-3].sym)->level))
       {
         werrorfl((yyvsp[-3].sym)->fileDef, (yyvsp[-3].sym)->lineDef, E_DUPLICATE_TYPEDEF,csym->name);
         werrorfl(csym->fileDef, csym->lineDef, E_PREVIOUS_DEF);
       }
     
     enumtype = newEnumType ((yyvsp[-1].sym));	//copyLinkChain(cenum->type);
     SPEC_SCLS(getSpec(enumtype)) = 0;
     (yyvsp[-3].sym)->type = enumtype;
     
     /* add this to the enumerator table */
     if (!csym)
       addSym ( enumTab,(yyvsp[-3].sym),(yyvsp[-3].sym)->name,(yyvsp[-3].sym)->level,(yyvsp[-3].sym)->block, 0);
     (yyval.lnk) = copyLinkChain(enumtype);
   }
    break;

  case 171:
#line 969 "SDCC.y"
    {
     symbol *csym ;
     
     /* check the enumerator table */
     if ((csym = findSym(enumTab,(yyvsp[0].sym),(yyvsp[0].sym)->name)))
       (yyval.lnk) = copyLinkChain(csym->type);
     else  {
       (yyval.lnk) = newLink(SPECIFIER) ;
       SPEC_NOUN((yyval.lnk)) = V_INT   ;
     }
   }
    break;

  case 173:
#line 984 "SDCC.y"
    {
                         }
    break;

  case 174:
#line 987 "SDCC.y"
    {
       symbol *dsym;
       
       for (dsym=(yyvsp[-2].sym); dsym; dsym=dsym->next)
         {
	   if (strcmp((yyvsp[0].sym)->name, dsym->name)==0)
	     {
	       werrorfl((yyvsp[0].sym)->fileDef, (yyvsp[0].sym)->lineDef, E_DUPLICATE_MEMBER, "enum", (yyvsp[0].sym)->name);
	       werrorfl(dsym->fileDef, dsym->lineDef, E_PREVIOUS_DEF);
	     }
	 }
       
       (yyvsp[0].sym)->next = (yyvsp[-2].sym) ;
       (yyval.sym) = (yyvsp[0].sym)  ;
     }
    break;

  case 175:
#line 1006 "SDCC.y"
    {
       /* make the symbol one level up */
       (yyvsp[-1].sym)->level-- ;
       (yyvsp[-1].sym)->type = copyLinkChain((yyvsp[0].val)->type); 
       (yyvsp[-1].sym)->etype= getSpec((yyvsp[-1].sym)->type);
       SPEC_ENUM((yyvsp[-1].sym)->etype) = 1;
       (yyval.sym) = (yyvsp[-1].sym) ;
       // do this now, so we can use it for the next enums in the list
       addSymChain(&(yyvsp[-1].sym));
     }
    break;

  case 176:
#line 1019 "SDCC.y"
    {
                              value *val ;

                              val = constExprValue((yyvsp[0].asts),TRUE);
			      if (!IS_INT(val->type) && !IS_CHAR(val->type))
			        {
				  werror(E_ENUM_NON_INTEGER);
				  SNPRINTF(lbuff, sizeof(lbuff), 
				 	  "%d",(int) floatFromVal(val));
				  val = constVal(lbuff);
				}
                              (yyval.val) = cenum = val ;
                           }
    break;

  case 177:
#line 1032 "SDCC.y"
    {                              
                              if (cenum)  {
                                 SNPRINTF(lbuff, sizeof(lbuff), 
				 	  "%d",(int) floatFromVal(cenum)+1);
                                 (yyval.val) = cenum = constVal(lbuff);
                              }
                              else {
                                 SNPRINTF(lbuff, sizeof(lbuff), 
				          "%d",0);
                                 (yyval.val) = cenum = constVal(lbuff);
                              }   
                           }
    break;

  case 178:
#line 1047 "SDCC.y"
    { (yyval.sym) = (yyvsp[0].sym) ; }
    break;

  case 179:
#line 1049 "SDCC.y"
    {
	     addDecl ((yyvsp[0].sym),0,reverseLink((yyvsp[-1].lnk)));
	     (yyval.sym) = (yyvsp[0].sym) ;
         }
    break;

  case 180:
#line 1056 "SDCC.y"
    { (yyval.sym) = (yyvsp[0].sym) ; }
    break;

  case 181:
#line 1057 "SDCC.y"
    { (yyval.sym) = (yyvsp[0].sym) ; }
    break;

  case 182:
#line 1061 "SDCC.y"
    { (yyval.sym) = (yyvsp[0].sym); }
    break;

  case 183:
#line 1063 "SDCC.y"
    {
	     addDecl ((yyvsp[0].sym),0,reverseLink((yyvsp[-1].lnk)));
	     (yyval.sym) = (yyvsp[0].sym) ;
         }
    break;

  case 184:
#line 1070 "SDCC.y"
    { (yyval.sym) = (yyvsp[0].sym) ; }
    break;

  case 185:
#line 1071 "SDCC.y"
    { 
           // copy the functionAttributes (not the args and hasVargs !!)
           struct value *args;
           unsigned hasVargs;
           sym_link *funcType=(yyvsp[-1].sym)->type;

	   while (funcType && !IS_FUNC(funcType))
	     funcType = funcType->next;
	   
	   if (!funcType)
	     werror (E_FUNC_ATTR);
	   else
	     {
	       args=FUNC_ARGS(funcType);
               hasVargs=FUNC_HASVARARGS(funcType);

               memcpy (&funcType->funcAttrs, &(yyvsp[0].lnk)->funcAttrs, 
    	           sizeof((yyvsp[0].lnk)->funcAttrs));

               FUNC_ARGS(funcType)=args;
               FUNC_HASVARARGS(funcType)=hasVargs;

               // just to be sure
               memset (&(yyvsp[0].lnk)->funcAttrs, 0,
    	           sizeof((yyvsp[0].lnk)->funcAttrs));
           
               addDecl ((yyvsp[-1].sym),0,(yyvsp[0].lnk)); 
	     }
   }
    break;

  case 187:
#line 1104 "SDCC.y"
    { (yyval.sym) = (yyvsp[-1].sym); }
    break;

  case 188:
#line 1106 "SDCC.y"
    {
            sym_link   *p;

            p = newLink (DECLARATOR);
            DCL_TYPE(p) = ARRAY ;
            DCL_ELEM(p) = 0     ;
            addDecl((yyvsp[-2].sym),0,p);
         }
    break;

  case 189:
#line 1115 "SDCC.y"
    {
            sym_link   *p ;
			value *tval;
			
            tval = constExprValue((yyvsp[-1].asts),TRUE);
            /* if it is not a constant then Error  */
            p = newLink (DECLARATOR);
            DCL_TYPE(p) = ARRAY ;
            if ( !tval || (SPEC_SCLS(tval->etype) != S_LITERAL)) {
               werror(E_CONST_EXPECTED) ;
               /* Assume a single item array to limit the cascade */
               /* of additional errors. */
               DCL_ELEM(p) = 1;
            }
            else {
               DCL_ELEM(p) = (int) floatFromVal(tval) ;
            }		                
            addDecl((yyvsp[-3].sym),0,p);
         }
    break;

  case 190:
#line 1137 "SDCC.y"
    {  addDecl ((yyvsp[-2].sym),FUNCTION,NULL) ;   }
    break;

  case 191:
#line 1138 "SDCC.y"
    { NestLevel++ ; currBlockno++;  }
    break;

  case 192:
#line 1140 "SDCC.y"
    {
             sym_link *funcType;
	   
	     addDecl ((yyvsp[-4].sym),FUNCTION,NULL) ;

	     funcType = (yyvsp[-4].sym)->type;
	     while (funcType && !IS_FUNC(funcType))
	       funcType = funcType->next;
	   
	     assert (funcType);
	     
	     FUNC_HASVARARGS(funcType) = IS_VARG((yyvsp[-1].val));
	     FUNC_ARGS(funcType) = reverseVal((yyvsp[-1].val));
	     
	     /* nest level was incremented to take care of the parms  */
	     NestLevel-- ;
	     currBlockno--;

	     // if this was a pointer (to a function)
	     if (!IS_FUNC((yyvsp[-4].sym)->type))
	       cleanUpLevel(SymbolTab,NestLevel+1);
	     
	     (yyval.sym) = (yyvsp[-4].sym);
         }
    break;

  case 193:
#line 1165 "SDCC.y"
    {	   
	   werror(E_OLD_STYLE,(yyvsp[-3].sym)->name) ;	  
	   /* assume it returns an int */
	   (yyvsp[-3].sym)->type = (yyvsp[-3].sym)->etype = newIntLink();
	   (yyval.sym) = (yyvsp[-3].sym) ;
         }
    break;

  case 194:
#line 1174 "SDCC.y"
    { (yyval.lnk) = (yyvsp[0].lnk) ;}
    break;

  case 195:
#line 1176 "SDCC.y"
    {
	     (yyval.lnk) = (yyvsp[-1].lnk)  ;
             if (IS_SPEC((yyvsp[0].lnk))) {
	         DCL_TSPEC((yyvsp[-1].lnk)) = (yyvsp[0].lnk);
                 DCL_PTR_CONST((yyvsp[-1].lnk)) = SPEC_CONST((yyvsp[0].lnk));
                 DCL_PTR_VOLATILE((yyvsp[-1].lnk)) = SPEC_VOLATILE((yyvsp[0].lnk));
             }
             else
                 werror (W_PTR_TYPE_INVALID);
	 }
    break;

  case 196:
#line 1187 "SDCC.y"
    {
	     (yyval.lnk) = (yyvsp[-1].lnk) ;		
	     (yyval.lnk)->next = (yyvsp[0].lnk) ;
	     DCL_TYPE((yyvsp[0].lnk))=port->unqualified_pointer;
	 }
    break;

  case 197:
#line 1193 "SDCC.y"
    {
	     (yyval.lnk) = (yyvsp[-2].lnk) ;  	     
	     if (IS_SPEC((yyvsp[-1].lnk)) && DCL_TYPE((yyvsp[0].lnk)) == UPOINTER) {
		 DCL_PTR_CONST((yyvsp[-2].lnk)) = SPEC_CONST((yyvsp[-1].lnk));
		 DCL_PTR_VOLATILE((yyvsp[-2].lnk)) = SPEC_VOLATILE((yyvsp[-1].lnk));
		 switch (SPEC_SCLS((yyvsp[-1].lnk))) {
		 case S_XDATA:
		     DCL_TYPE((yyvsp[0].lnk)) = FPOINTER;
		     break;
		 case S_IDATA:
		     DCL_TYPE((yyvsp[0].lnk)) = IPOINTER ;
		     break;
		 case S_PDATA:
		     DCL_TYPE((yyvsp[0].lnk)) = PPOINTER ;
		     break;
		 case S_DATA:
		     DCL_TYPE((yyvsp[0].lnk)) = POINTER ;
		     break;
		 case S_CODE:
		     DCL_TYPE((yyvsp[0].lnk)) = CPOINTER ;
		     break;
		 case S_EEPROM:
		     DCL_TYPE((yyvsp[0].lnk)) = EEPPOINTER;
		     break;
		 default:
		   // this could be just "constant" 
		   // werror(W_PTR_TYPE_INVALID);
		     ;
		 }
	     }
	     else 
		 werror (W_PTR_TYPE_INVALID);
	     (yyval.lnk)->next = (yyvsp[0].lnk) ;
	 }
    break;

  case 198:
#line 1231 "SDCC.y"
    {
	(yyval.lnk) = newLink(DECLARATOR);
	DCL_TYPE((yyval.lnk))=UPOINTER;
      }
    break;

  case 200:
#line 1240 "SDCC.y"
    {
     /* if the decl $2 is not a specifier */
     /* find the spec and replace it      */
     if ( !IS_SPEC((yyvsp[0].lnk))) {
       sym_link *lnk = (yyvsp[0].lnk) ;
       while (lnk && !IS_SPEC(lnk->next))
	 lnk = lnk->next;
       lnk->next = mergeSpec((yyvsp[-1].lnk),lnk->next, "type_specifier_list type_specifier skipped");
       (yyval.lnk) = (yyvsp[0].lnk) ;
     }
     else
       (yyval.lnk) = mergeSpec((yyvsp[-1].lnk),(yyvsp[0].lnk), "type_specifier_list type_specifier");
   }
    break;

  case 204:
#line 1263 "SDCC.y"
    {            
	   (yyvsp[0].sym)->next = (yyvsp[-2].sym);
	   (yyval.sym) = (yyvsp[0].sym) ;
         }
    break;

  case 206:
#line 1271 "SDCC.y"
    { (yyvsp[-2].val)->vArgs = 1;}
    break;

  case 208:
#line 1277 "SDCC.y"
    {
            (yyvsp[0].val)->next = (yyvsp[-2].val) ;
            (yyval.val) = (yyvsp[0].val) ;
         }
    break;

  case 209:
#line 1285 "SDCC.y"
    {	
		  symbol *loop ;
		  pointerTypes((yyvsp[0].sym)->type,(yyvsp[-1].lnk));
                  addDecl ((yyvsp[0].sym),0,(yyvsp[-1].lnk));		  
		  for (loop=(yyvsp[0].sym);loop;loop->_isparm=1,loop=loop->next);
		  addSymChain (&(yyvsp[0].sym));
		  (yyval.val) = symbolVal((yyvsp[0].sym));
		  ignoreTypedefType = 0;
               }
    break;

  case 210:
#line 1294 "SDCC.y"
    { 
                  (yyval.val) = newValue() ; 
                  (yyval.val)->type = (yyvsp[0].lnk);
                  (yyval.val)->etype = getSpec((yyval.val)->type);
                  ignoreTypedefType = 0;
               }
    break;

  case 211:
#line 1303 "SDCC.y"
    { (yyval.lnk) = (yyvsp[0].lnk); ignoreTypedefType = 0;}
    break;

  case 212:
#line 1305 "SDCC.y"
    {
		 /* go to the end of the list */
		 sym_link *p;
		 pointerTypes((yyvsp[0].lnk),(yyvsp[-1].lnk));
		 for ( p = (yyvsp[0].lnk) ; p && p->next ; p=p->next);
		 if (!p) {
		   werror(E_SYNTAX_ERROR, yytext);
		 } else {
		   p->next = (yyvsp[-1].lnk) ;
		 }
		 (yyval.lnk) = (yyvsp[0].lnk) ;
		 ignoreTypedefType = 0;
               }
    break;

  case 213:
#line 1321 "SDCC.y"
    { (yyval.lnk) = reverseLink((yyvsp[0].lnk)); }
    break;

  case 215:
#line 1323 "SDCC.y"
    { (yyvsp[-1].lnk) = reverseLink((yyvsp[-1].lnk)); (yyvsp[-1].lnk)->next = (yyvsp[0].lnk) ; (yyval.lnk) = (yyvsp[-1].lnk);
	  if (IS_PTR((yyvsp[-1].lnk)) && IS_FUNC((yyvsp[0].lnk)))
	    DCL_TYPE((yyvsp[-1].lnk)) = CPOINTER;
	}
    break;

  case 216:
#line 1330 "SDCC.y"
    { (yyval.lnk) = (yyvsp[-1].lnk) ; }
    break;

  case 217:
#line 1331 "SDCC.y"
    {             
                                       (yyval.lnk) = newLink (DECLARATOR);
                                       DCL_TYPE((yyval.lnk)) = ARRAY ;
                                       DCL_ELEM((yyval.lnk)) = 0     ;
                                    }
    break;

  case 218:
#line 1336 "SDCC.y"
    { 
                                       value *val ;
                                       (yyval.lnk) = newLink (DECLARATOR);
                                       DCL_TYPE((yyval.lnk)) = ARRAY ;
                                       DCL_ELEM((yyval.lnk)) = (int) floatFromVal(val = constExprValue((yyvsp[-1].asts),TRUE));
                                    }
    break;

  case 219:
#line 1342 "SDCC.y"
    {
                                       (yyval.lnk) = newLink (DECLARATOR);
                                       DCL_TYPE((yyval.lnk)) = ARRAY ;
                                       DCL_ELEM((yyval.lnk)) = 0     ;
                                       (yyval.lnk)->next = (yyvsp[-2].lnk) ;
                                    }
    break;

  case 220:
#line 1349 "SDCC.y"
    {
                                       value *val ;
                                       (yyval.lnk) = newLink (DECLARATOR);
                                       DCL_TYPE((yyval.lnk)) = ARRAY ;
                                       DCL_ELEM((yyval.lnk)) = (int) floatFromVal(val = constExprValue((yyvsp[-1].asts),TRUE));
                                       (yyval.lnk)->next = (yyvsp[-3].lnk) ;
                                    }
    break;

  case 221:
#line 1356 "SDCC.y"
    { (yyval.lnk) = NULL;}
    break;

  case 222:
#line 1357 "SDCC.y"
    { (yyval.lnk) = NULL;}
    break;

  case 223:
#line 1358 "SDCC.y"
    {
     // $1 must be a pointer to a function
     sym_link *p=newLink(DECLARATOR);
     DCL_TYPE(p) = FUNCTION;
     if (!(yyvsp[-2].lnk)) {
       // ((void (code *) ()) 0) ()
       (yyvsp[-2].lnk)=newLink(DECLARATOR);
       DCL_TYPE((yyvsp[-2].lnk))=CPOINTER;
       (yyval.lnk) = (yyvsp[-2].lnk);
     }
     (yyvsp[-2].lnk)->next=p;
   }
    break;

  case 224:
#line 1370 "SDCC.y"
    { NestLevel++ ; currBlockno++; }
    break;

  case 225:
#line 1370 "SDCC.y"
    {
       sym_link *p=newLink(DECLARATOR);
       DCL_TYPE(p) = FUNCTION;
	   
       FUNC_HASVARARGS(p) = IS_VARG((yyvsp[-1].val));
       FUNC_ARGS(p) = reverseVal((yyvsp[-1].val));

       /* nest level was incremented to take care of the parms  */
       NestLevel-- ;
       currBlockno--;
       if (!(yyvsp[-4].lnk)) {
         /* ((void (code *) (void)) 0) () */
         (yyvsp[-4].lnk)=newLink(DECLARATOR);
         DCL_TYPE((yyvsp[-4].lnk))=CPOINTER;
         (yyval.lnk) = (yyvsp[-4].lnk);
       }
       (yyvsp[-4].lnk)->next=p;

       // remove the symbol args (if any)
       cleanUpLevel(SymbolTab,NestLevel+1);
   }
    break;

  case 226:
#line 1394 "SDCC.y"
    { (yyval.ilist) = newiList(INIT_NODE,(yyvsp[0].asts)); }
    break;

  case 227:
#line 1395 "SDCC.y"
    { (yyval.ilist) = newiList(INIT_DEEP,revinit((yyvsp[-1].ilist))); }
    break;

  case 228:
#line 1396 "SDCC.y"
    { (yyval.ilist) = newiList(INIT_DEEP,revinit((yyvsp[-2].ilist))); }
    break;

  case 230:
#line 1401 "SDCC.y"
    {  (yyvsp[0].ilist)->next = (yyvsp[-2].ilist); (yyval.ilist) = (yyvsp[0].ilist); }
    break;

  case 238:
#line 1412 "SDCC.y"
    {
                            ast *ex;
			    seqPointNo++;
			    ex = newNode(INLINEASM,NULL,NULL);
			    ex->values.inlineasm = strdup((yyvsp[-1].yyinline));
			    seqPointNo++;
			    (yyval.asts) = ex;
                         }
    break;

  case 239:
#line 1423 "SDCC.y"
    {
		   inCritical++;
		   STACK_PUSH(continueStack,NULL);
		   STACK_PUSH(breakStack,NULL);
                   (yyval.sym) = NULL;
                }
    break;

  case 240:
#line 1432 "SDCC.y"
    {
		   STACK_POP(breakStack);
		   STACK_POP(continueStack);
		   inCritical--;
		   (yyval.asts) = newNode(CRITICAL,(yyvsp[0].asts),NULL);
                }
    break;

  case 241:
#line 1442 "SDCC.y"
    {  (yyval.asts) = createLabel((yyvsp[-1].sym),NULL);
					  (yyvsp[-1].sym)->isitmp = 0;  }
    break;

  case 242:
#line 1445 "SDCC.y"
    {
       if (STACK_EMPTY(swStk))
         (yyval.asts) = createCase(NULL,(yyvsp[-1].asts),NULL);
       else
         (yyval.asts) = createCase(STACK_PEEK(swStk),(yyvsp[-1].asts),NULL);
     }
    break;

  case 243:
#line 1451 "SDCC.y"
    { (yyval.asts) = newNode(DEFAULT,NULL,NULL); }
    break;

  case 244:
#line 1452 "SDCC.y"
    {
       if (STACK_EMPTY(swStk))
         (yyval.asts) = createDefault(NULL,(yyvsp[-1].asts),NULL);
       else
         (yyval.asts) = createDefault(STACK_PEEK(swStk),(yyvsp[-1].asts),NULL);
     }
    break;

  case 245:
#line 1461 "SDCC.y"
    {
	        STACK_PUSH(blockNum,currBlockno);
		currBlockno = ++blockNo ;
		ignoreTypedefType = 0;
	      }
    break;

  case 246:
#line 1468 "SDCC.y"
    { currBlockno = STACK_POP(blockNum); }
    break;

  case 247:
#line 1472 "SDCC.y"
    { (yyval.asts) = createBlock(NULL,NULL); }
    break;

  case 248:
#line 1473 "SDCC.y"
    { (yyval.asts) = createBlock(NULL,(yyvsp[-1].asts)) ;  }
    break;

  case 249:
#line 1475 "SDCC.y"
    { addSymChain(&(yyvsp[0].sym)); }
    break;

  case 250:
#line 1476 "SDCC.y"
    { (yyval.asts) = createBlock((yyvsp[-2].sym),NULL) ;  }
    break;

  case 251:
#line 1478 "SDCC.y"
    {  addSymChain (&(yyvsp[0].sym)); }
    break;

  case 252:
#line 1480 "SDCC.y"
    {(yyval.asts) = createBlock((yyvsp[-3].sym),(yyvsp[-1].asts))   ;  }
    break;

  case 253:
#line 1481 "SDCC.y"
    { (yyval.asts) = NULL ; }
    break;

  case 254:
#line 1486 "SDCC.y"
    {
       /* if this is typedef declare it immediately */
       if ( (yyvsp[0].sym) && IS_TYPEDEF((yyvsp[0].sym)->etype)) {
	 allocVariables ((yyvsp[0].sym));
	 (yyval.sym) = NULL ;
       }
       else
	 (yyval.sym) = (yyvsp[0].sym) ;
       ignoreTypedefType = 0;
     }
    break;

  case 255:
#line 1498 "SDCC.y"
    {
       symbol   *sym;
       
       /* if this is a typedef */
       if ((yyvsp[0].sym) && IS_TYPEDEF((yyvsp[0].sym)->etype)) {
	 allocVariables ((yyvsp[0].sym));
	 (yyval.sym) = (yyvsp[-1].sym) ;
       }
       else {
				/* get to the end of the previous decl */
	 if ( (yyvsp[-1].sym) ) {
	   (yyval.sym) = sym = (yyvsp[-1].sym) ;
	   while (sym->next)
	     sym = sym->next ;
	   sym->next = (yyvsp[0].sym);
	 } 
	 else
	   (yyval.sym) = (yyvsp[0].sym) ;
       }
       ignoreTypedefType = 0;
     }
    break;

  case 257:
#line 1523 "SDCC.y"
    {  (yyval.asts) = newNode(NULLOP,(yyvsp[-1].asts),(yyvsp[0].asts)) ;}
    break;

  case 258:
#line 1527 "SDCC.y"
    { (yyval.asts) = NULL;}
    break;

  case 259:
#line 1528 "SDCC.y"
    { (yyval.asts) = (yyvsp[-1].asts); seqPointNo++;}
    break;

  case 260:
#line 1532 "SDCC.y"
    { (yyval.asts) = (yyvsp[0].asts)  ; }
    break;

  case 261:
#line 1533 "SDCC.y"
    { (yyval.asts) = NULL;}
    break;

  case 262:
#line 1538 "SDCC.y"
    { seqPointNo++;}
    break;

  case 263:
#line 1539 "SDCC.y"
    {
			      noLineno++ ;
			      (yyval.asts) = createIf ((yyvsp[-4].asts), (yyvsp[-1].asts), (yyvsp[0].asts) );
			      noLineno--;
			   }
    break;

  case 264:
#line 1544 "SDCC.y"
    { 
                              ast *ex ;                              
                              static   int swLabel = 0 ;

			      seqPointNo++;
                              /* create a node for expression  */
                              ex = newNode(SWITCH,(yyvsp[-1].asts),NULL);
                              STACK_PUSH(swStk,ex);   /* save it in the stack */
                              ex->values.switchVals.swNum = swLabel ;
                                 
                              /* now create the label */
                              SNPRINTF(lbuff, sizeof(lbuff), 
			      	       "_swBrk_%d",swLabel++);
                              (yyval.sym)  =  newSymbol(lbuff,NestLevel);
                              /* put label in the break stack  */
                              STACK_PUSH(breakStack,(yyval.sym));   
                           }
    break;

  case 265:
#line 1561 "SDCC.y"
    {  
                              /* get back the switch form the stack  */
                              (yyval.asts) = STACK_POP(swStk)  ;
                              (yyval.asts)->right = newNode (NULLOP,(yyvsp[0].asts),createLabel((yyvsp[-1].sym),NULL));
                              STACK_POP(breakStack);   
                           }
    break;

  case 266:
#line 1569 "SDCC.y"
    {  /* create and push the continue , break & body labels */
                  static int Lblnum = 0 ;
		  /* continue */
                  SNPRINTF (lbuff, sizeof(lbuff), "_whilecontinue_%d",Lblnum);
		  STACK_PUSH(continueStack,newSymbol(lbuff,NestLevel));
		  /* break */
		  SNPRINTF (lbuff, sizeof(lbuff), "_whilebreak_%d",Lblnum);
		  STACK_PUSH(breakStack,newSymbol(lbuff,NestLevel));
		  /* body */
		  SNPRINTF (lbuff, sizeof(lbuff), "_whilebody_%d",Lblnum++);
		  (yyval.sym) = newSymbol(lbuff,NestLevel);
               }
    break;

  case 267:
#line 1583 "SDCC.y"
    {  /* create and push the continue , break & body Labels */
           static int Lblnum = 0 ;

	   /* continue */
	   SNPRINTF(lbuff, sizeof(lbuff), "_docontinue_%d",Lblnum);
	   STACK_PUSH(continueStack,newSymbol(lbuff,NestLevel));
	   /* break */
	   SNPRINTF(lbuff, sizeof(lbuff), "_dobreak_%d",Lblnum);
	   STACK_PUSH(breakStack,newSymbol(lbuff,NestLevel));
	   /* do body */
	   SNPRINTF(lbuff, sizeof(lbuff), "_dobody_%d",Lblnum++);
	   (yyval.sym) = newSymbol (lbuff,NestLevel);	   
        }
    break;

  case 268:
#line 1598 "SDCC.y"
    { /* create & push continue, break & body labels */
            static int Lblnum = 0 ;
         
            /* continue */
	    SNPRINTF(lbuff, sizeof(lbuff), "_forcontinue_%d",Lblnum);
	    STACK_PUSH(continueStack,newSymbol(lbuff,NestLevel));
	    /* break    */
	    SNPRINTF(lbuff, sizeof(lbuff), "_forbreak_%d",Lblnum);
	    STACK_PUSH(breakStack,newSymbol(lbuff,NestLevel));
	    /* body */
	    SNPRINTF(lbuff, sizeof(lbuff), "_forbody_%d",Lblnum);
	    (yyval.sym) = newSymbol(lbuff,NestLevel);
	    /* condition */
	    SNPRINTF(lbuff, sizeof(lbuff), "_forcond_%d",Lblnum++);
	    STACK_PUSH(forStack,newSymbol(lbuff,NestLevel));
          }
    break;

  case 269:
#line 1617 "SDCC.y"
    { seqPointNo++;}
    break;

  case 270:
#line 1618 "SDCC.y"
    { 
			   noLineno++ ;
			   (yyval.asts) = createWhile ( (yyvsp[-5].sym), STACK_POP(continueStack),
					      STACK_POP(breakStack), (yyvsp[-3].asts), (yyvsp[0].asts) ); 
			   (yyval.asts)->lineno = (yyvsp[-5].sym)->lineDef ;
			   noLineno-- ;
			 }
    break;

  case 271:
#line 1626 "SDCC.y"
    { 
			  seqPointNo++; 
			  noLineno++ ; 
			  (yyval.asts) = createDo ( (yyvsp[-6].sym) , STACK_POP(continueStack), 
					  STACK_POP(breakStack), (yyvsp[-2].asts), (yyvsp[-5].asts));
			  (yyval.asts)->lineno = (yyvsp[-6].sym)->lineDef ;
			  noLineno-- ;
			}
    break;

  case 272:
#line 1635 "SDCC.y"
    {
			  noLineno++ ;	
			  
			  /* if break or continue statement present
			     then create a general case loop */
			  if (STACK_PEEK(continueStack)->isref ||
			      STACK_PEEK(breakStack)->isref) {
			      (yyval.asts) = createFor ((yyvsp[-8].sym), STACK_POP(continueStack),
					      STACK_POP(breakStack) ,
					      STACK_POP(forStack)   ,
					      (yyvsp[-6].asts) , (yyvsp[-4].asts) , (yyvsp[-2].asts), (yyvsp[0].asts) );
			  } else {
			      (yyval.asts) = newNode(FOR,(yyvsp[0].asts),NULL);
			      AST_FOR((yyval.asts),trueLabel) = (yyvsp[-8].sym);
			      AST_FOR((yyval.asts),continueLabel) =  STACK_POP(continueStack);
			      AST_FOR((yyval.asts),falseLabel) = STACK_POP(breakStack);
			      AST_FOR((yyval.asts),condLabel)  = STACK_POP(forStack)  ;
			      AST_FOR((yyval.asts),initExpr)   = (yyvsp[-6].asts);
			      AST_FOR((yyval.asts),condExpr)   = (yyvsp[-4].asts);
			      AST_FOR((yyval.asts),loopExpr)   = (yyvsp[-2].asts);
			  }
			  
			  noLineno-- ;
			}
    break;

  case 273:
#line 1662 "SDCC.y"
    { (yyval.asts) = NULL ; seqPointNo++; }
    break;

  case 274:
#line 1663 "SDCC.y"
    { (yyval.asts) = (yyvsp[0].asts) ; seqPointNo++; }
    break;

  case 275:
#line 1667 "SDCC.y"
    { 
                              (yyvsp[-1].sym)->islbl = 1;
                              (yyval.asts) = newAst_VALUE(symbolVal((yyvsp[-1].sym))); 
                              (yyval.asts) = newNode(GOTO,(yyval.asts),NULL);
                           }
    break;

  case 276:
#line 1672 "SDCC.y"
    {  
       /* make sure continue is in context */
       if (STACK_EMPTY(continueStack) || STACK_PEEK(continueStack) == NULL) {
	   werror(E_BREAK_CONTEXT);
	   (yyval.asts) = NULL;
       }
       else {
	   (yyval.asts) = newAst_VALUE(symbolVal(STACK_PEEK(continueStack)));      
	   (yyval.asts) = newNode(GOTO,(yyval.asts),NULL);
	   /* mark the continue label as referenced */
	   STACK_PEEK(continueStack)->isref = 1;
       }
   }
    break;

  case 277:
#line 1685 "SDCC.y"
    { 
       if (STACK_EMPTY(breakStack) || STACK_PEEK(breakStack) == NULL) {
	   werror(E_BREAK_CONTEXT);
	   (yyval.asts) = NULL;
       } else {
	   (yyval.asts) = newAst_VALUE(symbolVal(STACK_PEEK(breakStack)));
	   (yyval.asts) = newNode(GOTO,(yyval.asts),NULL);
	   STACK_PEEK(breakStack)->isref = 1;
       }
   }
    break;

  case 278:
#line 1695 "SDCC.y"
    {
       seqPointNo++;
       if (inCritical) {
	   werror(E_INVALID_CRITICAL);
	   (yyval.asts) = NULL;
       } else {
	   (yyval.asts) = newNode(RETURN,NULL,NULL);
       }
   }
    break;

  case 279:
#line 1704 "SDCC.y"
    {
       seqPointNo++;
       if (inCritical) {
	   werror(E_INVALID_CRITICAL);
	   (yyval.asts) = NULL;
       } else {
	   (yyval.asts) = newNode(RETURN,NULL,(yyvsp[-1].asts));
       }
   }
    break;

  case 280:
#line 1716 "SDCC.y"
    { (yyval.sym) = newSymbol ((yyvsp[0].yychar),NestLevel) ; }
    break;


      default: break;
    }

/* Line 1126 of yacc.c.  */
#line 4200 "SDCCy.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  int yytype = YYTRANSLATE (yychar);
	  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
	  YYSIZE_T yysize = yysize0;
	  YYSIZE_T yysize1;
	  int yysize_overflow = 0;
	  char *yymsg = 0;
#	  define YYERROR_VERBOSE_ARGS_MAXIMUM 5
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;

#if 0
	  /* This is so xgettext sees the translatable formats that are
	     constructed on the fly.  */
	  YY_("syntax error, unexpected %s");
	  YY_("syntax error, unexpected %s, expecting %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
#endif
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytname[yytype];
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytname[yyx];
		yysize1 = yysize + yytnamerr (0, yytname[yyx]);
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + yystrlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow && yysize <= YYSTACK_ALLOC_MAXIMUM)
	    yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg)
	    {
	      /* Avoid sprintf, as that infringes on the user's name space.
		 Don't have undefined behavior even if the translation
		 produced a string with the wrong number of "%s"s.  */
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      goto yyexhaustedlab;
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
        }
      else
	{
	  yydestruct ("Error: discarding", yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (0)
     goto yyerrorlab;

yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping", yystos[yystate], yyvsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token. */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK;
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 1718 "SDCC.y"



